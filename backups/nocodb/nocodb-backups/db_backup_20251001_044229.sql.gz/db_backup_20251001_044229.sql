--
-- PostgreSQL database dump
--

\restrict yH8OQvbeEbM0HhpJYhb60y5TWEVFWOhvKvDckcR4NXNfZ7I1e6Rpn64pKIBHSfN

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pfc8llztqct90f1; Type: SCHEMA; Schema: -; Owner: nocodb
--

CREATE SCHEMA pfc8llztqct90f1;


ALTER SCHEMA pfc8llztqct90f1 OWNER TO nocodb;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Features; Type: TABLE; Schema: pfc8llztqct90f1; Owner: nocodb
--

CREATE TABLE pfc8llztqct90f1."Features" (
    id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    created_by character varying,
    updated_by character varying,
    nc_order numeric,
    title text
);


ALTER TABLE pfc8llztqct90f1."Features" OWNER TO nocodb;

--
-- Name: Features_id_seq; Type: SEQUENCE; Schema: pfc8llztqct90f1; Owner: nocodb
--

CREATE SEQUENCE pfc8llztqct90f1."Features_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pfc8llztqct90f1."Features_id_seq" OWNER TO nocodb;

--
-- Name: Features_id_seq; Type: SEQUENCE OWNED BY; Schema: pfc8llztqct90f1; Owner: nocodb
--

ALTER SEQUENCE pfc8llztqct90f1."Features_id_seq" OWNED BY pfc8llztqct90f1."Features".id;


--
-- Name: nc_api_tokens; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_api_tokens (
    id integer NOT NULL,
    base_id character varying(20),
    db_alias character varying(255),
    description character varying(255),
    permissions text,
    token text,
    expiry character varying(255),
    enabled boolean DEFAULT true,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    fk_user_id character varying(20),
    fk_sso_client_id character varying(20)
);


ALTER TABLE public.nc_api_tokens OWNER TO nocodb;

--
-- Name: nc_api_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: nocodb
--

CREATE SEQUENCE public.nc_api_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nc_api_tokens_id_seq OWNER TO nocodb;

--
-- Name: nc_api_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocodb
--

ALTER SEQUENCE public.nc_api_tokens_id_seq OWNED BY public.nc_api_tokens.id;


--
-- Name: nc_audit_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_audit_v2 (
    id uuid NOT NULL,
    "user" character varying(255),
    ip character varying(255),
    source_id character varying(20),
    base_id character varying(20),
    fk_model_id character varying(20),
    row_id character varying(255),
    op_type character varying(255),
    op_sub_type character varying(255),
    status character varying(255),
    description text,
    details text,
    fk_user_id character varying(20),
    fk_ref_id character varying(20),
    fk_parent_id uuid,
    fk_workspace_id character varying(20),
    fk_org_id character varying(20),
    user_agent text,
    version smallint DEFAULT '0'::smallint,
    old_id character varying(20),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_audit_v2 OWNER TO nocodb;

--
-- Name: nc_audit_v2_old; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_audit_v2_old (
    id character varying(20) NOT NULL,
    "user" character varying(255),
    ip character varying(255),
    source_id character varying(20),
    base_id character varying(20),
    fk_model_id character varying(20),
    row_id character varying(255),
    op_type character varying(255),
    op_sub_type character varying(255),
    status character varying(255),
    description text,
    details text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    version smallint DEFAULT '0'::smallint,
    fk_user_id character varying(20),
    fk_ref_id character varying(20),
    fk_parent_id character varying(20),
    user_agent text
);


ALTER TABLE public.nc_audit_v2_old OWNER TO nocodb;

--
-- Name: nc_base_users_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_base_users_v2 (
    base_id character varying(20) NOT NULL,
    fk_user_id character varying(20) NOT NULL,
    roles text,
    starred boolean,
    pinned boolean,
    "group" character varying(255),
    color character varying(255),
    "order" real,
    hidden real,
    opened_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    invited_by character varying(20)
);


ALTER TABLE public.nc_base_users_v2 OWNER TO nocodb;

--
-- Name: nc_bases_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_bases_v2 (
    id character varying(128) NOT NULL,
    title character varying(255),
    prefix character varying(255),
    status character varying(255),
    description text,
    meta text,
    color character varying(255),
    uuid character varying(255),
    password character varying(255),
    roles character varying(255),
    deleted boolean DEFAULT false,
    is_meta boolean,
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    default_role character varying(20)
);


ALTER TABLE public.nc_bases_v2 OWNER TO nocodb;

--
-- Name: nc_calendar_view_columns_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_calendar_view_columns_v2 (
    id character varying(20) NOT NULL,
    base_id character varying(20),
    source_id character varying(20),
    fk_view_id character varying(20),
    fk_column_id character varying(20),
    show boolean,
    bold boolean,
    underline boolean,
    italic boolean,
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_calendar_view_columns_v2 OWNER TO nocodb;

--
-- Name: nc_calendar_view_range_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_calendar_view_range_v2 (
    id character varying(20) NOT NULL,
    fk_view_id character varying(20),
    fk_to_column_id character varying(20),
    label character varying(40),
    fk_from_column_id character varying(20),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    base_id character varying(20)
);


ALTER TABLE public.nc_calendar_view_range_v2 OWNER TO nocodb;

--
-- Name: nc_calendar_view_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_calendar_view_v2 (
    fk_view_id character varying(20) NOT NULL,
    base_id character varying(20),
    source_id character varying(20),
    title character varying(255),
    fk_cover_image_col_id character varying(20),
    meta text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.nc_calendar_view_v2 OWNER TO nocodb;

--
-- Name: nc_col_barcode_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_col_barcode_v2 (
    id character varying(20) NOT NULL,
    fk_column_id character varying(20),
    fk_barcode_value_column_id character varying(20),
    barcode_format character varying(15),
    deleted boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    base_id character varying(20)
);


ALTER TABLE public.nc_col_barcode_v2 OWNER TO nocodb;

--
-- Name: nc_col_button_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_col_button_v2 (
    id character varying(20) NOT NULL,
    base_id character varying(20),
    type character varying(255),
    label text,
    theme character varying(255),
    color character varying(255),
    icon character varying(255),
    formula text,
    formula_raw text,
    error character varying(255),
    parsed_tree text,
    fk_webhook_id character varying(20),
    fk_column_id character varying(20),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    fk_integration_id character varying(20),
    model character varying(255),
    output_column_ids text,
    fk_workspace_id character varying(20)
);


ALTER TABLE public.nc_col_button_v2 OWNER TO nocodb;

--
-- Name: nc_col_formula_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_col_formula_v2 (
    id character varying(20) NOT NULL,
    fk_column_id character varying(20),
    formula text NOT NULL,
    formula_raw text,
    error text,
    deleted boolean,
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    parsed_tree text,
    base_id character varying(20)
);


ALTER TABLE public.nc_col_formula_v2 OWNER TO nocodb;

--
-- Name: nc_col_long_text_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_col_long_text_v2 (
    id character varying(20) NOT NULL,
    fk_workspace_id character varying(20),
    base_id character varying(20),
    fk_model_id character varying(20),
    fk_column_id character varying(20),
    fk_integration_id character varying(20),
    model character varying(255),
    prompt text,
    prompt_raw text,
    error text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_col_long_text_v2 OWNER TO nocodb;

--
-- Name: nc_col_lookup_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_col_lookup_v2 (
    id character varying(20) NOT NULL,
    fk_column_id character varying(20),
    fk_relation_column_id character varying(20),
    fk_lookup_column_id character varying(20),
    deleted boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    base_id character varying(20)
);


ALTER TABLE public.nc_col_lookup_v2 OWNER TO nocodb;

--
-- Name: nc_col_qrcode_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_col_qrcode_v2 (
    id character varying(20) NOT NULL,
    fk_column_id character varying(20),
    fk_qr_value_column_id character varying(20),
    deleted boolean,
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    base_id character varying(20)
);


ALTER TABLE public.nc_col_qrcode_v2 OWNER TO nocodb;

--
-- Name: nc_col_relations_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_col_relations_v2 (
    id character varying(20) NOT NULL,
    ref_db_alias character varying(255),
    type character varying(255),
    virtual boolean,
    db_type character varying(255),
    fk_column_id character varying(20),
    fk_related_model_id character varying(20),
    fk_child_column_id character varying(20),
    fk_parent_column_id character varying(20),
    fk_mm_model_id character varying(20),
    fk_mm_child_column_id character varying(20),
    fk_mm_parent_column_id character varying(20),
    ur character varying(255),
    dr character varying(255),
    fk_index_name character varying(255),
    deleted boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    fk_target_view_id character varying(20),
    base_id character varying(20),
    fk_related_base_id character varying(20),
    fk_mm_base_id character varying(20),
    fk_related_source_id character varying(20),
    fk_mm_source_id character varying(20)
);


ALTER TABLE public.nc_col_relations_v2 OWNER TO nocodb;

--
-- Name: nc_col_rollup_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_col_rollup_v2 (
    id character varying(20) NOT NULL,
    fk_column_id character varying(20),
    fk_relation_column_id character varying(20),
    fk_rollup_column_id character varying(20),
    rollup_function character varying(255),
    deleted boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    base_id character varying(20)
);


ALTER TABLE public.nc_col_rollup_v2 OWNER TO nocodb;

--
-- Name: nc_col_select_options_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_col_select_options_v2 (
    id character varying(20) NOT NULL,
    fk_column_id character varying(20),
    title character varying(255),
    color character varying(255),
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    base_id character varying(20)
);


ALTER TABLE public.nc_col_select_options_v2 OWNER TO nocodb;

--
-- Name: nc_columns_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_columns_v2 (
    id character varying(20) NOT NULL,
    source_id character varying(20),
    base_id character varying(20),
    fk_model_id character varying(20),
    title character varying(255),
    column_name character varying(255),
    uidt character varying(255),
    dt character varying(255),
    np character varying(255),
    ns character varying(255),
    clen character varying(255),
    cop character varying(255),
    pk boolean,
    pv boolean,
    rqd boolean,
    un boolean,
    ct text,
    ai boolean,
    "unique" boolean,
    cdf text,
    cc text,
    csn character varying(255),
    dtx character varying(255),
    dtxp text,
    dtxs character varying(255),
    au boolean,
    validate text,
    virtual boolean,
    deleted boolean,
    system boolean DEFAULT false,
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    meta text,
    description text,
    readonly boolean DEFAULT false,
    custom_index_name character varying(64)
);


ALTER TABLE public.nc_columns_v2 OWNER TO nocodb;

--
-- Name: nc_comment_reactions; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_comment_reactions (
    id character varying(20) NOT NULL,
    row_id character varying(255),
    comment_id character varying(20),
    source_id character varying(20),
    fk_model_id character varying(20),
    base_id character varying(20),
    reaction character varying(255),
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_comment_reactions OWNER TO nocodb;

--
-- Name: nc_comments; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_comments (
    id character varying(20) NOT NULL,
    row_id character varying(255),
    comment text,
    created_by character varying(20),
    created_by_email character varying(255),
    resolved_by character varying(20),
    resolved_by_email character varying(255),
    parent_comment_id character varying(20),
    source_id character varying(20),
    base_id character varying(20),
    fk_model_id character varying(20),
    is_deleted boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_comments OWNER TO nocodb;

--
-- Name: nc_dashboards_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_dashboards_v2 (
    id character varying(20) NOT NULL,
    fk_workspace_id character varying(20),
    base_id character varying(20),
    title character varying(255) NOT NULL,
    description text,
    meta text,
    "order" integer,
    created_by character varying(20),
    owned_by character varying(20),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    uuid character varying(255),
    password character varying(255),
    fk_custom_url_id character varying(20)
);


ALTER TABLE public.nc_dashboards_v2 OWNER TO nocodb;

--
-- Name: nc_data_reflection; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_data_reflection (
    id character varying(20) NOT NULL,
    fk_workspace_id character varying(20),
    username character varying(255),
    password character varying(255),
    database character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_data_reflection OWNER TO nocodb;

--
-- Name: nc_disabled_models_for_role_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_disabled_models_for_role_v2 (
    id character varying(20) NOT NULL,
    source_id character varying(20),
    base_id character varying(20),
    fk_view_id character varying(20),
    role character varying(45),
    disabled boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_disabled_models_for_role_v2 OWNER TO nocodb;

--
-- Name: nc_extensions; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_extensions (
    id character varying(20) NOT NULL,
    base_id character varying(20),
    fk_user_id character varying(20),
    extension_id character varying(255),
    title character varying(255),
    kv_store text,
    meta text,
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_extensions OWNER TO nocodb;

--
-- Name: nc_file_references; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_file_references (
    id character varying(20) NOT NULL,
    storage character varying(255),
    file_url text,
    file_size integer,
    fk_user_id character varying(20),
    fk_workspace_id character varying(20),
    base_id character varying(20),
    source_id character varying(20),
    fk_model_id character varying(20),
    fk_column_id character varying(20),
    is_external boolean DEFAULT false,
    deleted boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_file_references OWNER TO nocodb;

--
-- Name: nc_filter_exp_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_filter_exp_v2 (
    id character varying(20) NOT NULL,
    source_id character varying(20),
    base_id character varying(20),
    fk_view_id character varying(20),
    fk_hook_id character varying(20),
    fk_column_id character varying(20),
    fk_parent_id character varying(20),
    logical_op character varying(255),
    comparison_op character varying(255),
    value text,
    is_group boolean,
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    comparison_sub_op character varying(255),
    fk_link_col_id character varying(20),
    fk_value_col_id character varying(20),
    fk_parent_column_id character varying(20),
    fk_row_color_condition_id character varying(20),
    fk_widget_id character varying(20)
);


ALTER TABLE public.nc_filter_exp_v2 OWNER TO nocodb;

--
-- Name: nc_form_view_columns_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_form_view_columns_v2 (
    id character varying(20) NOT NULL,
    source_id character varying(20),
    base_id character varying(20),
    fk_view_id character varying(20),
    fk_column_id character varying(20),
    uuid character varying(255),
    label text,
    help text,
    description text,
    required boolean,
    show boolean,
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    meta text,
    enable_scanner boolean
);


ALTER TABLE public.nc_form_view_columns_v2 OWNER TO nocodb;

--
-- Name: nc_form_view_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_form_view_v2 (
    source_id character varying(20),
    base_id character varying(20),
    fk_view_id character varying(20) NOT NULL,
    heading character varying(255),
    subheading text,
    success_msg text,
    redirect_url text,
    redirect_after_secs character varying(255),
    email character varying(255),
    submit_another_form boolean,
    show_blank_form boolean,
    uuid character varying(255),
    banner_image_url text,
    logo_url text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    meta text
);


ALTER TABLE public.nc_form_view_v2 OWNER TO nocodb;

--
-- Name: nc_gallery_view_columns_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_gallery_view_columns_v2 (
    id character varying(20) NOT NULL,
    source_id character varying(20),
    base_id character varying(20),
    fk_view_id character varying(20),
    fk_column_id character varying(20),
    uuid character varying(255),
    label character varying(255),
    help character varying(255),
    show boolean,
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_gallery_view_columns_v2 OWNER TO nocodb;

--
-- Name: nc_gallery_view_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_gallery_view_v2 (
    source_id character varying(20),
    base_id character varying(20),
    fk_view_id character varying(20) NOT NULL,
    next_enabled boolean,
    prev_enabled boolean,
    cover_image_idx integer,
    fk_cover_image_col_id character varying(20),
    cover_image character varying(255),
    restrict_types character varying(255),
    restrict_size character varying(255),
    restrict_number character varying(255),
    public boolean,
    dimensions character varying(255),
    responsive_columns character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    meta text
);


ALTER TABLE public.nc_gallery_view_v2 OWNER TO nocodb;

--
-- Name: nc_grid_view_columns_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_grid_view_columns_v2 (
    id character varying(20) NOT NULL,
    fk_view_id character varying(20),
    fk_column_id character varying(20),
    source_id character varying(20),
    base_id character varying(20),
    uuid character varying(255),
    label character varying(255),
    help character varying(255),
    width character varying(255) DEFAULT '200px'::character varying,
    show boolean,
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    group_by boolean,
    group_by_order real,
    group_by_sort character varying(255),
    aggregation character varying(30) DEFAULT NULL::character varying
);


ALTER TABLE public.nc_grid_view_columns_v2 OWNER TO nocodb;

--
-- Name: nc_grid_view_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_grid_view_v2 (
    fk_view_id character varying(20) NOT NULL,
    source_id character varying(20),
    base_id character varying(20),
    uuid character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    meta text,
    row_height integer
);


ALTER TABLE public.nc_grid_view_v2 OWNER TO nocodb;

--
-- Name: nc_hook_logs_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_hook_logs_v2 (
    id character varying(20) NOT NULL,
    source_id character varying(20),
    base_id character varying(20),
    fk_hook_id character varying(20),
    type character varying(255),
    event character varying(255),
    operation character varying(255),
    test_call boolean DEFAULT true,
    payload text,
    conditions text,
    notification text,
    error_code character varying(255),
    error_message character varying(255),
    error text,
    execution_time integer,
    response text,
    triggered_by character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_hook_logs_v2 OWNER TO nocodb;

--
-- Name: nc_hook_trigger_fields; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_hook_trigger_fields (
    fk_hook_id character varying(20) NOT NULL,
    fk_column_id character varying(20) NOT NULL,
    base_id character varying(20) NOT NULL,
    fk_workspace_id character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_hook_trigger_fields OWNER TO nocodb;

--
-- Name: nc_hooks_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_hooks_v2 (
    id character varying(20) NOT NULL,
    source_id character varying(20),
    base_id character varying(20),
    fk_model_id character varying(20),
    title character varying(255),
    description character varying(255),
    env character varying(255) DEFAULT 'all'::character varying,
    type character varying(255),
    event character varying(255),
    operation character varying(255),
    async boolean DEFAULT false,
    payload boolean DEFAULT true,
    url text,
    headers text,
    condition boolean DEFAULT false,
    notification text,
    retries integer DEFAULT 0,
    retry_interval integer DEFAULT 60000,
    timeout integer DEFAULT 60000,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    version character varying(255),
    trigger_field boolean DEFAULT false
);


ALTER TABLE public.nc_hooks_v2 OWNER TO nocodb;

--
-- Name: nc_integrations_store_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_integrations_store_v2 (
    id character varying(20) NOT NULL,
    fk_integration_id character varying(20),
    type character varying(20),
    sub_type character varying(20),
    fk_workspace_id character varying(20),
    fk_user_id character varying(20),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    slot_0 text,
    slot_1 text,
    slot_2 text,
    slot_3 text,
    slot_4 text,
    slot_5 integer,
    slot_6 integer,
    slot_7 integer,
    slot_8 integer,
    slot_9 integer
);


ALTER TABLE public.nc_integrations_store_v2 OWNER TO nocodb;

--
-- Name: nc_integrations_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_integrations_v2 (
    id character varying(20) NOT NULL,
    title character varying(128),
    config text,
    meta text,
    type character varying(20),
    sub_type character varying(20),
    is_private boolean DEFAULT false,
    deleted boolean DEFAULT false,
    created_by character varying(20),
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    is_default boolean DEFAULT false,
    is_encrypted boolean DEFAULT false
);


ALTER TABLE public.nc_integrations_v2 OWNER TO nocodb;

--
-- Name: nc_jobs; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_jobs (
    id character varying(20) NOT NULL,
    job character varying(255),
    status character varying(20),
    result text,
    fk_user_id character varying(20),
    fk_workspace_id character varying(20),
    base_id character varying(20),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_jobs OWNER TO nocodb;

--
-- Name: nc_kanban_view_columns_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_kanban_view_columns_v2 (
    id character varying(20) NOT NULL,
    source_id character varying(20),
    base_id character varying(20),
    fk_view_id character varying(20),
    fk_column_id character varying(20),
    uuid character varying(255),
    label character varying(255),
    help character varying(255),
    show boolean,
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_kanban_view_columns_v2 OWNER TO nocodb;

--
-- Name: nc_kanban_view_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_kanban_view_v2 (
    fk_view_id character varying(20) NOT NULL,
    source_id character varying(20),
    base_id character varying(20),
    show boolean,
    "order" real,
    uuid character varying(255),
    title character varying(255),
    public boolean,
    password character varying(255),
    show_all_fields boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    fk_grp_col_id character varying(20),
    fk_cover_image_col_id character varying(20),
    meta text
);


ALTER TABLE public.nc_kanban_view_v2 OWNER TO nocodb;

--
-- Name: nc_map_view_columns_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_map_view_columns_v2 (
    id character varying(20) NOT NULL,
    base_id character varying(20),
    project_id character varying(128),
    fk_view_id character varying(20),
    fk_column_id character varying(20),
    uuid character varying(255),
    label character varying(255),
    help character varying(255),
    show boolean,
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_map_view_columns_v2 OWNER TO nocodb;

--
-- Name: nc_map_view_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_map_view_v2 (
    fk_view_id character varying(20) NOT NULL,
    source_id character varying(20),
    base_id character varying(20),
    uuid character varying(255),
    title character varying(255),
    fk_geo_data_col_id character varying(20),
    meta text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.nc_map_view_v2 OWNER TO nocodb;

--
-- Name: nc_mcp_tokens; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_mcp_tokens (
    id character varying(20) NOT NULL,
    title character varying(512),
    base_id character varying(20),
    token character varying(32),
    fk_workspace_id character varying(20),
    "order" real,
    fk_user_id character varying(20),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_mcp_tokens OWNER TO nocodb;

--
-- Name: nc_models_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_models_v2 (
    id character varying(20) NOT NULL,
    source_id character varying(20),
    base_id character varying(20),
    table_name character varying(255),
    title character varying(255),
    type character varying(255) DEFAULT 'table'::character varying,
    meta text,
    schema text,
    enabled boolean DEFAULT true,
    mm boolean DEFAULT false,
    tags character varying(255),
    pinned boolean,
    deleted boolean,
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    description text,
    synced boolean DEFAULT false,
    created_by character varying(20),
    owned_by character varying(20),
    uuid character varying(255),
    password character varying(255),
    fk_custom_url_id character varying(20)
);


ALTER TABLE public.nc_models_v2 OWNER TO nocodb;

--
-- Name: nc_orgs_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_orgs_v2 (
    id character varying(20) NOT NULL,
    title character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_orgs_v2 OWNER TO nocodb;

--
-- Name: nc_permission_subjects; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_permission_subjects (
    fk_permission_id character varying(20) NOT NULL,
    subject_type character varying(255) NOT NULL,
    subject_id character varying(255) NOT NULL,
    fk_workspace_id character varying(20),
    base_id character varying(20),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_permission_subjects OWNER TO nocodb;

--
-- Name: nc_permissions; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_permissions (
    id character varying(20) NOT NULL,
    fk_workspace_id character varying(20),
    base_id character varying(20),
    entity character varying(255),
    entity_id character varying(255),
    permission character varying(255),
    created_by character varying(20),
    enforce_for_form boolean DEFAULT true,
    enforce_for_automation boolean DEFAULT true,
    granted_type character varying(255),
    granted_role character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_permissions OWNER TO nocodb;

--
-- Name: nc_plugins_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_plugins_v2 (
    id character varying(20) NOT NULL,
    title character varying(45),
    description text,
    active boolean DEFAULT false,
    rating real,
    version character varying(255),
    docs character varying(255),
    status character varying(255) DEFAULT 'install'::character varying,
    status_details character varying(255),
    logo character varying(255),
    icon character varying(255),
    tags character varying(255),
    category character varying(255),
    input_schema text,
    input text,
    creator character varying(255),
    creator_website character varying(255),
    price character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_plugins_v2 OWNER TO nocodb;

--
-- Name: nc_row_color_conditions; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_row_color_conditions (
    id character varying(20) NOT NULL,
    fk_view_id character varying(20),
    fk_workspace_id character varying(20),
    base_id character varying(20),
    color character varying(20),
    nc_order integer,
    is_set_as_background boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_row_color_conditions OWNER TO nocodb;

--
-- Name: nc_shared_bases; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_shared_bases (
    id integer NOT NULL,
    project_id character varying(255),
    db_alias character varying(255),
    roles character varying(255) DEFAULT 'viewer'::character varying,
    shared_base_id character varying(255),
    enabled boolean DEFAULT true,
    password character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_shared_bases OWNER TO nocodb;

--
-- Name: nc_shared_bases_id_seq; Type: SEQUENCE; Schema: public; Owner: nocodb
--

CREATE SEQUENCE public.nc_shared_bases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nc_shared_bases_id_seq OWNER TO nocodb;

--
-- Name: nc_shared_bases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocodb
--

ALTER SEQUENCE public.nc_shared_bases_id_seq OWNED BY public.nc_shared_bases.id;


--
-- Name: nc_shared_views_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_shared_views_v2 (
    id character varying(20) NOT NULL,
    fk_view_id character varying(20),
    meta text,
    query_params text,
    view_id character varying(255),
    show_all_fields boolean,
    allow_copy boolean,
    password character varying(255),
    deleted boolean,
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_shared_views_v2 OWNER TO nocodb;

--
-- Name: nc_sort_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_sort_v2 (
    id character varying(20) NOT NULL,
    source_id character varying(20),
    base_id character varying(20),
    fk_view_id character varying(20),
    fk_column_id character varying(20),
    direction character varying(255) DEFAULT 'false'::character varying,
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_sort_v2 OWNER TO nocodb;

--
-- Name: nc_sources_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_sources_v2 (
    id character varying(20) NOT NULL,
    base_id character varying(20),
    alias character varying(255),
    config text,
    meta text,
    is_meta boolean,
    type character varying(255),
    inflection_column character varying(255),
    inflection_table character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    enabled boolean DEFAULT true,
    "order" real,
    description character varying(255),
    erd_uuid character varying(255),
    deleted boolean DEFAULT false,
    is_schema_readonly boolean DEFAULT false,
    is_data_readonly boolean DEFAULT false,
    fk_integration_id character varying(20),
    is_local boolean DEFAULT false,
    is_encrypted boolean DEFAULT false
);


ALTER TABLE public.nc_sources_v2 OWNER TO nocodb;

--
-- Name: nc_store; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_store (
    id integer NOT NULL,
    base_id character varying(255),
    db_alias character varying(255) DEFAULT 'db'::character varying,
    key character varying(255),
    value text,
    type character varying(255),
    env character varying(255),
    tag character varying(255),
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.nc_store OWNER TO nocodb;

--
-- Name: nc_store_id_seq; Type: SEQUENCE; Schema: public; Owner: nocodb
--

CREATE SEQUENCE public.nc_store_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nc_store_id_seq OWNER TO nocodb;

--
-- Name: nc_store_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocodb
--

ALTER SEQUENCE public.nc_store_id_seq OWNED BY public.nc_store.id;


--
-- Name: nc_sync_configs; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_sync_configs (
    id character varying(20) NOT NULL,
    fk_workspace_id character varying(20),
    base_id character varying(20),
    fk_integration_id character varying(20),
    fk_model_id character varying(20),
    sync_type character varying(255),
    sync_trigger character varying(255),
    sync_trigger_cron character varying(255),
    sync_trigger_secret character varying(255),
    sync_job_id character varying(255),
    last_sync_at timestamp with time zone,
    next_sync_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    title character varying(255),
    sync_category character varying(255),
    fk_parent_sync_config_id character varying(20),
    on_delete_action character varying(255) DEFAULT 'mark_deleted'::character varying
);


ALTER TABLE public.nc_sync_configs OWNER TO nocodb;

--
-- Name: nc_sync_logs_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_sync_logs_v2 (
    id character varying(20) NOT NULL,
    base_id character varying(20),
    fk_sync_source_id character varying(20),
    time_taken integer,
    status character varying(255),
    status_details text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_sync_logs_v2 OWNER TO nocodb;

--
-- Name: nc_sync_mappings; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_sync_mappings (
    id character varying(20) NOT NULL,
    fk_workspace_id character varying(20),
    base_id character varying(20),
    fk_sync_config_id character varying(20),
    target_table character varying(255),
    fk_model_id character varying(20),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_sync_mappings OWNER TO nocodb;

--
-- Name: nc_sync_source_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_sync_source_v2 (
    id character varying(20) NOT NULL,
    title character varying(255),
    type character varying(255),
    details text,
    deleted boolean,
    enabled boolean DEFAULT true,
    "order" real,
    base_id character varying(20),
    fk_user_id character varying(20),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    source_id character varying(20)
);


ALTER TABLE public.nc_sync_source_v2 OWNER TO nocodb;

--
-- Name: nc_team_users_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_team_users_v2 (
    org_id character varying(20),
    user_id character varying(20),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_team_users_v2 OWNER TO nocodb;

--
-- Name: nc_teams_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_teams_v2 (
    id character varying(20) NOT NULL,
    title character varying(255),
    org_id character varying(20),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_teams_v2 OWNER TO nocodb;

--
-- Name: nc_user_comment_notifications_preference; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_user_comment_notifications_preference (
    id character varying(20) NOT NULL,
    row_id character varying(255),
    user_id character varying(20),
    fk_model_id character varying(20),
    source_id character varying(20),
    base_id character varying(20),
    preferences character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_user_comment_notifications_preference OWNER TO nocodb;

--
-- Name: nc_user_refresh_tokens; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_user_refresh_tokens (
    fk_user_id character varying(20),
    token character varying(255),
    meta text,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.nc_user_refresh_tokens OWNER TO nocodb;

--
-- Name: nc_users_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_users_v2 (
    id character varying(20) NOT NULL,
    email character varying(255),
    password character varying(255),
    salt character varying(255),
    invite_token character varying(255),
    invite_token_expires character varying(255),
    reset_password_expires timestamp with time zone,
    reset_password_token character varying(255),
    email_verification_token character varying(255),
    email_verified boolean,
    roles character varying(255) DEFAULT 'editor'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    token_version character varying(255),
    display_name character varying(255),
    user_name character varying(255),
    blocked boolean DEFAULT false,
    blocked_reason character varying(255),
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    meta text,
    is_new_user boolean
);


ALTER TABLE public.nc_users_v2 OWNER TO nocodb;

--
-- Name: nc_views_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_views_v2 (
    id character varying(20) NOT NULL,
    source_id character varying(20),
    base_id character varying(20),
    fk_model_id character varying(20),
    title character varying(255),
    type integer,
    is_default boolean,
    show_system_fields boolean,
    lock_type character varying(255) DEFAULT 'collaborative'::character varying,
    uuid character varying(255),
    password character varying(255),
    show boolean,
    "order" real,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    meta text,
    description text,
    created_by character varying(20),
    owned_by character varying(20),
    row_coloring_mode character varying(10)
);


ALTER TABLE public.nc_views_v2 OWNER TO nocodb;

--
-- Name: nc_widgets_v2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.nc_widgets_v2 (
    id character varying(20) NOT NULL,
    fk_workspace_id character varying(20),
    base_id character varying(20),
    fk_dashboard_id character varying(20) NOT NULL,
    fk_model_id character varying(20),
    fk_view_id character varying(20),
    title character varying(255) NOT NULL,
    description text,
    type character varying(50) NOT NULL,
    config text,
    meta text,
    "order" integer,
    "position" text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    error boolean
);


ALTER TABLE public.nc_widgets_v2 OWNER TO nocodb;

--
-- Name: notification; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.notification (
    id character varying(20) NOT NULL,
    type character varying(40),
    body text,
    is_read boolean DEFAULT false,
    is_deleted boolean DEFAULT false,
    fk_user_id character varying(20),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.notification OWNER TO nocodb;

--
-- Name: xc_knex_migrations; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.xc_knex_migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


ALTER TABLE public.xc_knex_migrations OWNER TO nocodb;

--
-- Name: xc_knex_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: nocodb
--

CREATE SEQUENCE public.xc_knex_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xc_knex_migrations_id_seq OWNER TO nocodb;

--
-- Name: xc_knex_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocodb
--

ALTER SEQUENCE public.xc_knex_migrations_id_seq OWNED BY public.xc_knex_migrations.id;


--
-- Name: xc_knex_migrations_lock; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.xc_knex_migrations_lock (
    index integer NOT NULL,
    is_locked integer
);


ALTER TABLE public.xc_knex_migrations_lock OWNER TO nocodb;

--
-- Name: xc_knex_migrations_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: nocodb
--

CREATE SEQUENCE public.xc_knex_migrations_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xc_knex_migrations_lock_index_seq OWNER TO nocodb;

--
-- Name: xc_knex_migrations_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocodb
--

ALTER SEQUENCE public.xc_knex_migrations_lock_index_seq OWNED BY public.xc_knex_migrations_lock.index;


--
-- Name: xc_knex_migrationsv2; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.xc_knex_migrationsv2 (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


ALTER TABLE public.xc_knex_migrationsv2 OWNER TO nocodb;

--
-- Name: xc_knex_migrationsv2_id_seq; Type: SEQUENCE; Schema: public; Owner: nocodb
--

CREATE SEQUENCE public.xc_knex_migrationsv2_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xc_knex_migrationsv2_id_seq OWNER TO nocodb;

--
-- Name: xc_knex_migrationsv2_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocodb
--

ALTER SEQUENCE public.xc_knex_migrationsv2_id_seq OWNED BY public.xc_knex_migrationsv2.id;


--
-- Name: xc_knex_migrationsv2_lock; Type: TABLE; Schema: public; Owner: nocodb
--

CREATE TABLE public.xc_knex_migrationsv2_lock (
    index integer NOT NULL,
    is_locked integer
);


ALTER TABLE public.xc_knex_migrationsv2_lock OWNER TO nocodb;

--
-- Name: xc_knex_migrationsv2_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: nocodb
--

CREATE SEQUENCE public.xc_knex_migrationsv2_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xc_knex_migrationsv2_lock_index_seq OWNER TO nocodb;

--
-- Name: xc_knex_migrationsv2_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocodb
--

ALTER SEQUENCE public.xc_knex_migrationsv2_lock_index_seq OWNED BY public.xc_knex_migrationsv2_lock.index;


--
-- Name: Features id; Type: DEFAULT; Schema: pfc8llztqct90f1; Owner: nocodb
--

ALTER TABLE ONLY pfc8llztqct90f1."Features" ALTER COLUMN id SET DEFAULT nextval('pfc8llztqct90f1."Features_id_seq"'::regclass);


--
-- Name: nc_api_tokens id; Type: DEFAULT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_api_tokens ALTER COLUMN id SET DEFAULT nextval('public.nc_api_tokens_id_seq'::regclass);


--
-- Name: nc_shared_bases id; Type: DEFAULT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_shared_bases ALTER COLUMN id SET DEFAULT nextval('public.nc_shared_bases_id_seq'::regclass);


--
-- Name: nc_store id; Type: DEFAULT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_store ALTER COLUMN id SET DEFAULT nextval('public.nc_store_id_seq'::regclass);


--
-- Name: xc_knex_migrations id; Type: DEFAULT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.xc_knex_migrations ALTER COLUMN id SET DEFAULT nextval('public.xc_knex_migrations_id_seq'::regclass);


--
-- Name: xc_knex_migrations_lock index; Type: DEFAULT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.xc_knex_migrations_lock ALTER COLUMN index SET DEFAULT nextval('public.xc_knex_migrations_lock_index_seq'::regclass);


--
-- Name: xc_knex_migrationsv2 id; Type: DEFAULT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.xc_knex_migrationsv2 ALTER COLUMN id SET DEFAULT nextval('public.xc_knex_migrationsv2_id_seq'::regclass);


--
-- Name: xc_knex_migrationsv2_lock index; Type: DEFAULT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.xc_knex_migrationsv2_lock ALTER COLUMN index SET DEFAULT nextval('public.xc_knex_migrationsv2_lock_index_seq'::regclass);


--
-- Data for Name: Features; Type: TABLE DATA; Schema: pfc8llztqct90f1; Owner: nocodb
--

COPY pfc8llztqct90f1."Features" (id, created_at, updated_at, created_by, updated_by, nc_order, title) FROM stdin;
\.


--
-- Data for Name: nc_api_tokens; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_api_tokens (id, base_id, db_alias, description, permissions, token, expiry, enabled, created_at, updated_at, fk_user_id, fk_sso_client_id) FROM stdin;
\.


--
-- Data for Name: nc_audit_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_audit_v2 (id, "user", ip, source_id, base_id, fk_model_id, row_id, op_type, op_sub_type, status, description, details, fk_user_id, fk_ref_id, fk_parent_id, fk_workspace_id, fk_org_id, user_agent, version, old_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_audit_v2_old; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_audit_v2_old (id, "user", ip, source_id, base_id, fk_model_id, row_id, op_type, op_sub_type, status, description, details, created_at, updated_at, version, fk_user_id, fk_ref_id, fk_parent_id, user_agent) FROM stdin;
\.


--
-- Data for Name: nc_base_users_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_base_users_v2 (base_id, fk_user_id, roles, starred, pinned, "group", color, "order", hidden, opened_date, created_at, updated_at, invited_by) FROM stdin;
pfc8llztqct90f1	us960mxogxe71ra8	owner	\N	\N	\N	\N	\N	\N	\N	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	\N
\.


--
-- Data for Name: nc_bases_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_bases_v2 (id, title, prefix, status, description, meta, color, uuid, password, roles, deleted, is_meta, "order", created_at, updated_at, default_role) FROM stdin;
pfc8llztqct90f1	Getting Started		\N	\N	{"iconColor":"#36BFFF"}	\N	\N	\N	\N	f	t	1	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	\N
\.


--
-- Data for Name: nc_calendar_view_columns_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_calendar_view_columns_v2 (id, base_id, source_id, fk_view_id, fk_column_id, show, bold, underline, italic, "order", created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_calendar_view_range_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_calendar_view_range_v2 (id, fk_view_id, fk_to_column_id, label, fk_from_column_id, created_at, updated_at, base_id) FROM stdin;
\.


--
-- Data for Name: nc_calendar_view_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_calendar_view_v2 (fk_view_id, base_id, source_id, title, fk_cover_image_col_id, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_col_barcode_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_col_barcode_v2 (id, fk_column_id, fk_barcode_value_column_id, barcode_format, deleted, created_at, updated_at, base_id) FROM stdin;
\.


--
-- Data for Name: nc_col_button_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_col_button_v2 (id, base_id, type, label, theme, color, icon, formula, formula_raw, error, parsed_tree, fk_webhook_id, fk_column_id, created_at, updated_at, fk_integration_id, model, output_column_ids, fk_workspace_id) FROM stdin;
\.


--
-- Data for Name: nc_col_formula_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_col_formula_v2 (id, fk_column_id, formula, formula_raw, error, deleted, "order", created_at, updated_at, parsed_tree, base_id) FROM stdin;
\.


--
-- Data for Name: nc_col_long_text_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_col_long_text_v2 (id, fk_workspace_id, base_id, fk_model_id, fk_column_id, fk_integration_id, model, prompt, prompt_raw, error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_col_lookup_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_col_lookup_v2 (id, fk_column_id, fk_relation_column_id, fk_lookup_column_id, deleted, created_at, updated_at, base_id) FROM stdin;
\.


--
-- Data for Name: nc_col_qrcode_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_col_qrcode_v2 (id, fk_column_id, fk_qr_value_column_id, deleted, "order", created_at, updated_at, base_id) FROM stdin;
\.


--
-- Data for Name: nc_col_relations_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_col_relations_v2 (id, ref_db_alias, type, virtual, db_type, fk_column_id, fk_related_model_id, fk_child_column_id, fk_parent_column_id, fk_mm_model_id, fk_mm_child_column_id, fk_mm_parent_column_id, ur, dr, fk_index_name, deleted, created_at, updated_at, fk_target_view_id, base_id, fk_related_base_id, fk_mm_base_id, fk_related_source_id, fk_mm_source_id) FROM stdin;
\.


--
-- Data for Name: nc_col_rollup_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_col_rollup_v2 (id, fk_column_id, fk_relation_column_id, fk_rollup_column_id, rollup_function, deleted, created_at, updated_at, base_id) FROM stdin;
\.


--
-- Data for Name: nc_col_select_options_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_col_select_options_v2 (id, fk_column_id, title, color, "order", created_at, updated_at, base_id) FROM stdin;
\.


--
-- Data for Name: nc_columns_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_columns_v2 (id, source_id, base_id, fk_model_id, title, column_name, uidt, dt, np, ns, clen, cop, pk, pv, rqd, un, ct, ai, "unique", cdf, cc, csn, dtx, dtxp, dtxs, au, validate, virtual, deleted, system, "order", created_at, updated_at, meta, description, readonly, custom_index_name) FROM stdin;
cg02x6p1pfd0tus	brs1tao0osug2is	pfc8llztqct90f1	mjrhqhpwjb0teal	Id	id	ID	int4	11	0	\N	\N	t	\N	t	f	int(11)	t	\N	\N	\N	\N	integer	11		\N	\N	\N	\N	\N	1	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	{}	\N	f	\N
cnw20olheojwid1	brs1tao0osug2is	pfc8llztqct90f1	mjrhqhpwjb0teal	CreatedAt	created_at	CreatedTime	timestamp	\N	\N	45	\N	f	\N	f	f	timestamp	f	\N	\N	\N	\N	specificType			\N	\N	\N	\N	t	2	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	{}	\N	f	\N
cjhi8goql5th32y	brs1tao0osug2is	pfc8llztqct90f1	mjrhqhpwjb0teal	UpdatedAt	updated_at	LastModifiedTime	timestamp	\N	\N	45	\N	f	\N	f	f	timestamp	f	\N	\N	\N	\N	specificType			\N	\N	\N	\N	t	3	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	{}	\N	f	\N
c26cyiva14kmg0v	brs1tao0osug2is	pfc8llztqct90f1	mjrhqhpwjb0teal	nc_created_by	created_by	CreatedBy	varchar	\N	\N	45	\N	f	\N	f	f	varchar(45)	f	\N	\N	\N	\N	specificType	45		\N	\N	\N	\N	t	4	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	{}	\N	f	\N
c2elxjafr099f7k	brs1tao0osug2is	pfc8llztqct90f1	mjrhqhpwjb0teal	nc_updated_by	updated_by	LastModifiedBy	varchar	\N	\N	45	\N	f	\N	f	f	varchar(45)	f	\N	\N	\N	\N	specificType	45		\N	\N	\N	\N	t	5	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	{}	\N	f	\N
csfrw0o0kitypf2	brs1tao0osug2is	pfc8llztqct90f1	mjrhqhpwjb0teal	nc_order	nc_order	Order	numeric	40	20	\N	\N	f	\N	f	f	numeric(40,20)	f	\N	\N	\N	\N	specificType	40,20		\N	\N	\N	\N	t	6	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	{}	\N	f	\N
cksfizcyl6mps50	brs1tao0osug2is	pfc8llztqct90f1	mjrhqhpwjb0teal	Title	title	SingleLineText	TEXT	\N	\N	\N	\N	f	t	f	f	\N	f	\N	\N	\N	\N	specificType			\N	\N	\N	\N	\N	7	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	{}	\N	f	\N
\.


--
-- Data for Name: nc_comment_reactions; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_comment_reactions (id, row_id, comment_id, source_id, fk_model_id, base_id, reaction, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_comments; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_comments (id, row_id, comment, created_by, created_by_email, resolved_by, resolved_by_email, parent_comment_id, source_id, base_id, fk_model_id, is_deleted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_dashboards_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_dashboards_v2 (id, fk_workspace_id, base_id, title, description, meta, "order", created_by, owned_by, created_at, updated_at, uuid, password, fk_custom_url_id) FROM stdin;
\.


--
-- Data for Name: nc_data_reflection; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_data_reflection (id, fk_workspace_id, username, password, database, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_disabled_models_for_role_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_disabled_models_for_role_v2 (id, source_id, base_id, fk_view_id, role, disabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_extensions; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_extensions (id, base_id, fk_user_id, extension_id, title, kv_store, meta, "order", created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_file_references; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_file_references (id, storage, file_url, file_size, fk_user_id, fk_workspace_id, base_id, source_id, fk_model_id, fk_column_id, is_external, deleted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_filter_exp_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_filter_exp_v2 (id, source_id, base_id, fk_view_id, fk_hook_id, fk_column_id, fk_parent_id, logical_op, comparison_op, value, is_group, "order", created_at, updated_at, comparison_sub_op, fk_link_col_id, fk_value_col_id, fk_parent_column_id, fk_row_color_condition_id, fk_widget_id) FROM stdin;
\.


--
-- Data for Name: nc_form_view_columns_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_form_view_columns_v2 (id, source_id, base_id, fk_view_id, fk_column_id, uuid, label, help, description, required, show, "order", created_at, updated_at, meta, enable_scanner) FROM stdin;
\.


--
-- Data for Name: nc_form_view_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_form_view_v2 (source_id, base_id, fk_view_id, heading, subheading, success_msg, redirect_url, redirect_after_secs, email, submit_another_form, show_blank_form, uuid, banner_image_url, logo_url, created_at, updated_at, meta) FROM stdin;
\.


--
-- Data for Name: nc_gallery_view_columns_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_gallery_view_columns_v2 (id, source_id, base_id, fk_view_id, fk_column_id, uuid, label, help, show, "order", created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_gallery_view_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_gallery_view_v2 (source_id, base_id, fk_view_id, next_enabled, prev_enabled, cover_image_idx, fk_cover_image_col_id, cover_image, restrict_types, restrict_size, restrict_number, public, dimensions, responsive_columns, created_at, updated_at, meta) FROM stdin;
\.


--
-- Data for Name: nc_grid_view_columns_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_grid_view_columns_v2 (id, fk_view_id, fk_column_id, source_id, base_id, uuid, label, help, width, show, "order", created_at, updated_at, group_by, group_by_order, group_by_sort, aggregation) FROM stdin;
nc330ye1pyrd1ec1	vwvc9j4w93gk01yp	cg02x6p1pfd0tus	brs1tao0osug2is	pfc8llztqct90f1	\N	\N	\N	200px	t	1	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	\N	\N	\N	none
nc1uxuvs3x0ohmwi	vwvc9j4w93gk01yp	cnw20olheojwid1	brs1tao0osug2is	pfc8llztqct90f1	\N	\N	\N	200px	t	2	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	\N	\N	\N	none
nc2h2ie14n8k7qid	vwvc9j4w93gk01yp	cjhi8goql5th32y	brs1tao0osug2is	pfc8llztqct90f1	\N	\N	\N	200px	t	3	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	\N	\N	\N	none
ncdvqzq7pcmraiyl	vwvc9j4w93gk01yp	c26cyiva14kmg0v	brs1tao0osug2is	pfc8llztqct90f1	\N	\N	\N	200px	t	4	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	\N	\N	\N	none
ncqladdx7p5uaxaw	vwvc9j4w93gk01yp	c2elxjafr099f7k	brs1tao0osug2is	pfc8llztqct90f1	\N	\N	\N	200px	t	5	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	\N	\N	\N	none
ncco7vgko01vvenn	vwvc9j4w93gk01yp	csfrw0o0kitypf2	brs1tao0osug2is	pfc8llztqct90f1	\N	\N	\N	200px	t	6	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	\N	\N	\N	none
nc5fsp1f5yaje387	vwvc9j4w93gk01yp	cksfizcyl6mps50	brs1tao0osug2is	pfc8llztqct90f1	\N	\N	\N	200px	t	7	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	\N	\N	\N	none
\.


--
-- Data for Name: nc_grid_view_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_grid_view_v2 (fk_view_id, source_id, base_id, uuid, created_at, updated_at, meta, row_height) FROM stdin;
vwvc9j4w93gk01yp	brs1tao0osug2is	pfc8llztqct90f1	\N	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	\N	\N
\.


--
-- Data for Name: nc_hook_logs_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_hook_logs_v2 (id, source_id, base_id, fk_hook_id, type, event, operation, test_call, payload, conditions, notification, error_code, error_message, error, execution_time, response, triggered_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_hook_trigger_fields; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_hook_trigger_fields (fk_hook_id, fk_column_id, base_id, fk_workspace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_hooks_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_hooks_v2 (id, source_id, base_id, fk_model_id, title, description, env, type, event, operation, async, payload, url, headers, condition, notification, retries, retry_interval, timeout, active, created_at, updated_at, version, trigger_field) FROM stdin;
\.


--
-- Data for Name: nc_integrations_store_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_integrations_store_v2 (id, fk_integration_id, type, sub_type, fk_workspace_id, fk_user_id, created_at, updated_at, slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9) FROM stdin;
\.


--
-- Data for Name: nc_integrations_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_integrations_v2 (id, title, config, meta, type, sub_type, is_private, deleted, created_by, "order", created_at, updated_at, is_default, is_encrypted) FROM stdin;
\.


--
-- Data for Name: nc_jobs; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_jobs (id, job, status, result, fk_user_id, fk_workspace_id, base_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_kanban_view_columns_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_kanban_view_columns_v2 (id, source_id, base_id, fk_view_id, fk_column_id, uuid, label, help, show, "order", created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_kanban_view_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_kanban_view_v2 (fk_view_id, source_id, base_id, show, "order", uuid, title, public, password, show_all_fields, created_at, updated_at, fk_grp_col_id, fk_cover_image_col_id, meta) FROM stdin;
\.


--
-- Data for Name: nc_map_view_columns_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_map_view_columns_v2 (id, base_id, project_id, fk_view_id, fk_column_id, uuid, label, help, show, "order", created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_map_view_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_map_view_v2 (fk_view_id, source_id, base_id, uuid, title, fk_geo_data_col_id, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_mcp_tokens; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_mcp_tokens (id, title, base_id, token, fk_workspace_id, "order", fk_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_models_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_models_v2 (id, source_id, base_id, table_name, title, type, meta, schema, enabled, mm, tags, pinned, deleted, "order", created_at, updated_at, description, synced, created_by, owned_by, uuid, password, fk_custom_url_id) FROM stdin;
mjrhqhpwjb0teal	brs1tao0osug2is	pfc8llztqct90f1	Features	Features	table	\N	\N	t	f	\N	\N	\N	1	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	\N	f	\N	\N	\N	\N	\N
\.


--
-- Data for Name: nc_orgs_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_orgs_v2 (id, title, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_permission_subjects; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_permission_subjects (fk_permission_id, subject_type, subject_id, fk_workspace_id, base_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_permissions; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_permissions (id, fk_workspace_id, base_id, entity, entity_id, permission, created_by, enforce_for_form, enforce_for_automation, granted_type, granted_role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_plugins_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_plugins_v2 (id, title, description, active, rating, version, docs, status, status_details, logo, icon, tags, category, input_schema, input, creator, creator_website, price, created_at, updated_at) FROM stdin;
slack	Slack	Slack brings team communication and collaboration into one place so you can get more work done, whether you belong to a large enterprise or a small business. 	f	\N	0.0.1	\N	install	\N	plugins/slack.webp	\N	Chat	Chat	{"title":"Configure Slack","array":true,"items":[{"key":"channel","label":"Channel Name","placeholder":"Channel Name","type":"SingleLineText","required":true},{"key":"webhook_url","label":"Webhook URL","placeholder":"Webhook URL","type":"Password","required":true}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully installed and Slack is enabled for notification.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
ms-teams	Microsoft Teams	Microsoft Teams is for everyone · Instantly go from group chat to video call with the touch of a button.	f	\N	0.0.1	\N	install	\N	plugins/teams.ico	\N	Chat	Chat	{"title":"Configure Microsoft Teams","array":true,"items":[{"key":"channel","label":"Channel Name","placeholder":"Channel Name","type":"SingleLineText","required":true},{"key":"webhook_url","label":"Webhook URL","placeholder":"Webhook URL","type":"Password","required":true}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully installed and Microsoft Teams is enabled for notification.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
discord	Discord	Discord is the easiest way to talk over voice, video, and text. Talk, chat, hang out, and stay close with your friends and communities.	f	\N	0.0.1	\N	install	\N	plugins/discord.png	\N	Chat	Chat	{"title":"Configure Discord","array":true,"items":[{"key":"channel","label":"Channel Name","placeholder":"Channel Name","type":"SingleLineText","required":true},{"key":"webhook_url","label":"Webhook URL","type":"Password","placeholder":"Webhook URL","required":true}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully installed and Discord is enabled for notification.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
twilio-whatsapp	Whatsapp Twilio	With Twilio, unite communications and strengthen customer relationships across your business – from marketing and sales to customer service and operations.	f	\N	0.0.1	\N	install	\N	plugins/whatsapp.png	\N	Chat	Twilio	{"title":"Configure Twilio","items":[{"key":"sid","label":"Account SID","placeholder":"Account SID","type":"SingleLineText","required":true},{"key":"token","label":"Auth Token","placeholder":"Auth Token","type":"Password","required":true},{"key":"from","label":"From Phone Number","placeholder":"From Phone Number","type":"SingleLineText","required":true}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully installed and Whatsapp Twilio is enabled for notification.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
twilio	Twilio	With Twilio, unite communications and strengthen customer relationships across your business – from marketing and sales to customer service and operations.	f	\N	0.0.1	\N	install	\N	plugins/twilio.png	\N	Chat	Twilio	{"title":"Configure Twilio","items":[{"key":"sid","label":"Account SID","placeholder":"Account SID","type":"SingleLineText","required":true},{"key":"token","label":"Auth Token","placeholder":"Auth Token","type":"Password","required":true},{"key":"from","label":"From Phone Number","placeholder":"From Phone Number","type":"SingleLineText","required":true}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully installed and Twilio is enabled for notification.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
aws-s3	S3	Amazon Simple Storage Service (Amazon S3) is an object storage service that offers industry-leading scalability, data availability, security, and performance.	f	\N	0.0.6	\N	install	\N	plugins/s3.png	\N	Storage	Storage	{"title":"Configure Amazon S3","items":[{"key":"bucket","label":"Bucket Name","placeholder":"Bucket Name","type":"SingleLineText","required":true},{"key":"region","label":"Region","placeholder":"Region","type":"SingleLineText","required":true},{"key":"endpoint","label":"Endpoint","placeholder":"Endpoint","type":"SingleLineText","required":false},{"key":"access_key","label":"Access Key","placeholder":"Access Key","type":"SingleLineText","required":false},{"key":"access_secret","label":"Access Secret","placeholder":"Access Secret","type":"Password","required":false},{"key":"acl","label":"Access Control Lists (ACL)","placeholder":"","type":"SingleLineText","required":false},{"key":"force_path_style","label":"Force Path Style","placeholder":"Default set to false","type":"Checkbox","required":false}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully configured! Attachments will now be stored in AWS S3.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
minio	Minio	MinIO is a High Performance Object Storage released under Apache License v2.0. It is API compatible with Amazon S3 cloud storage service.	f	\N	0.0.5	\N	install	\N	plugins/minio.png	\N	Storage	Storage	{"title":"Configure Minio","items":[{"key":"endPoint","label":"Minio Endpoint","placeholder":"Minio Endpoint","type":"SingleLineText","required":true,"help_text":"Hostnames can’t include underscores (_) due to DNS standard limitations. Update the hostname if you see an Invalid endpoint error."},{"key":"port","label":"Port","placeholder":"Port","type":"Number","required":true},{"key":"bucket","label":"Bucket Name","placeholder":"Bucket Name","type":"SingleLineText","required":true},{"key":"access_key","label":"Access Key","placeholder":"Access Key","type":"SingleLineText","required":true},{"key":"access_secret","label":"Access Secret","placeholder":"Access Secret","type":"Password","required":true},{"key":"ca","label":"Ca","placeholder":"Ca","type":"LongText"},{"key":"useSSL","label":"Use SSL","placeholder":"Use SSL","type":"Checkbox","required":false}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully configured! Attachments will now be stored in Minio.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
gcs	GCS	Google Cloud Storage is a RESTful online file storage web service for storing and accessing data on Google Cloud Platform infrastructure.	f	\N	0.0.4	\N	install	\N	plugins/gcs.png	\N	Storage	Storage	{"title":"Configure Google Cloud Storage","items":[{"key":"bucket","label":"Bucket Name","placeholder":"Bucket Name","type":"SingleLineText","required":true},{"key":"client_email","label":"Client Email","placeholder":"Client Email","type":"SingleLineText","required":true},{"key":"private_key","label":"Private Key","placeholder":"Private Key","type":"Password","required":true},{"key":"project_id","label":"Project ID","placeholder":"Project ID","type":"SingleLineText","required":false},{"key":"uniform_bucket_level_access","label":"Uniform Bucket Level Access","type":"Checkbox","required":false}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully configured! Attachments will now be stored in Google Cloud Storage.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
mattermost	Mattermost	Mattermost brings all your team communication into one place, making it searchable and accessible anywhere.	f	\N	0.0.1	\N	install	\N	plugins/mattermost.png	\N	Chat	Chat	{"title":"Configure Mattermost","array":true,"items":[{"key":"channel","label":"Channel Name","placeholder":"Channel Name","type":"SingleLineText","required":true},{"key":"webhook_url","label":"Webhook URL","placeholder":"Webhook URL","type":"Password","required":true}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully installed and Mattermost is enabled for notification.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
spaces	Spaces	Store & deliver vast amounts of content with a simple architecture.	f	\N	0.0.2	\N	install	\N	plugins/spaces.png	\N	Storage	Storage	{"title":"DigitalOcean Spaces","items":[{"key":"bucket","label":"Bucket Name","placeholder":"Bucket Name","type":"SingleLineText","required":true},{"key":"region","label":"Region","placeholder":"Region","type":"SingleLineText","required":true},{"key":"access_key","label":"Access Key","placeholder":"Access Key","type":"SingleLineText","required":true},{"key":"access_secret","label":"Access Secret","placeholder":"Access Secret","type":"Password","required":true},{"key":"acl","label":"Access Control Lists (ACL)","placeholder":"Default set to public-read","type":"SingleLineText","required":false}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully configured! Attachments will now be stored in DigitalOcean Spaces.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
backblaze	Backblaze	Backblaze B2 is enterprise-grade, S3 compatible storage that companies around the world use to store and serve data while improving their cloud OpEx vs. Amazon S3 and others.	f	\N	0.0.5	\N	install	\N	plugins/backblaze.jpeg	\N	Storage	Storage	{"title":"Configure Backblaze B2","items":[{"key":"bucket","label":"Bucket Name","placeholder":"Bucket Name","type":"SingleLineText","required":true},{"key":"region","label":"Region","placeholder":"e.g. us-west-001","type":"SingleLineText","required":true},{"key":"access_key","label":"Access Key","placeholder":"i.e. keyID in App Keys","type":"SingleLineText","required":true},{"key":"access_secret","label":"Access Secret","placeholder":"i.e. applicationKey in App Keys","type":"Password","required":true},{"key":"acl","label":"Access Control Lists (ACL)","placeholder":"Default set to public-read","type":"SingleLineText","required":false}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully configured! Attachments will now be stored in Backblaze B2.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
vultr	Vultr	Using Vultr Object Storage can give flexibility and cloud storage that allows applications greater flexibility and access worldwide.	f	\N	0.0.4	\N	install	\N	plugins/vultr.png	\N	Storage	Storage	{"title":"Configure Vultr Object Storage","items":[{"key":"bucket","label":"Bucket Name","placeholder":"Bucket Name","type":"SingleLineText","required":true},{"key":"hostname","label":"Host Name","placeholder":"e.g.: ewr1.vultrobjects.com","type":"SingleLineText","required":true},{"key":"access_key","label":"Access Key","placeholder":"Access Key","type":"SingleLineText","required":true},{"key":"access_secret","label":"Access Secret","placeholder":"Access Secret","type":"Password","required":true},{"key":"acl","label":"Access Control Lists (ACL)","placeholder":"Default set to public-read","type":"SingleLineText","required":false}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully configured! Attachments will now be stored in Vultr Object Storage.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
ovh	Ovh	Upload your files to a space that you can access via HTTPS using the OpenStack Swift API, or the S3 API. 	f	\N	0.0.4	\N	install	\N	plugins/ovhCloud.png	\N	Storage	Storage	{"title":"Configure OvhCloud Object Storage","items":[{"key":"bucket","label":"Bucket Name","placeholder":"Bucket Name","type":"SingleLineText","required":true},{"key":"region","label":"Region","placeholder":"Region","type":"SingleLineText","required":true},{"key":"access_key","label":"Access Key","placeholder":"Access Key","type":"SingleLineText","required":true},{"key":"access_secret","label":"Access Secret","placeholder":"Access Secret","type":"Password","required":true},{"key":"acl","label":"Access Control Lists (ACL)","placeholder":"Default set to public-read","type":"SingleLineText","required":false}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully configured! Attachments will now be stored in OvhCloud Object Storage.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
linode	Linode	S3-compatible Linode Object Storage makes it easy and more affordable to manage unstructured data such as content assets, as well as sophisticated and data-intensive storage challenges around artificial intelligence and machine learning.	f	\N	0.0.4	\N	install	\N	plugins/linode.svg	\N	Storage	Storage	{"title":"Configure Linode Object Storage","items":[{"key":"bucket","label":"Bucket Name","placeholder":"Bucket Name","type":"SingleLineText","required":true},{"key":"region","label":"Region","placeholder":"Region","type":"SingleLineText","required":true},{"key":"access_key","label":"Access Key","placeholder":"Access Key","type":"SingleLineText","required":true},{"key":"access_secret","label":"Access Secret","placeholder":"Access Secret","type":"Password","required":true},{"key":"acl","label":"Access Control Lists (ACL)","placeholder":"Default set to public-read","type":"SingleLineText","required":false}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully configured! Attachments will now be stored in Linode Object Storage.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
upcloud	UpCloud	The perfect home for your data. Thanks to the S3-compatible programmable interface,\nyou have a host of options for existing tools and code implementations.\n	f	\N	0.0.4	\N	install	\N	plugins/upcloud.png	\N	Storage	Storage	{"title":"Configure UpCloud Object Storage","items":[{"key":"bucket","label":"Bucket Name","placeholder":"Bucket Name","type":"SingleLineText","required":true},{"key":"endpoint","label":"Endpoint","placeholder":"Endpoint","type":"SingleLineText","required":true},{"key":"access_key","label":"Access Key","placeholder":"Access Key","type":"SingleLineText","required":true},{"key":"access_secret","label":"Access Secret","placeholder":"Access Secret","type":"Password","required":true},{"key":"acl","label":"Access Control Lists (ACL)","placeholder":"Default set to public-read","type":"SingleLineText","required":false}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully configured! Attachments will now be stored in UpCloud Object Storage.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
smtp	SMTP	SMTP email client	f	\N	0.0.5	\N	install	\N	\N	\N	Email	Email	{"title":"Configure Email SMTP","items":[{"key":"from","label":"From address","placeholder":"admin@example.com","type":"SingleLineText","required":true,"help_text":"Enter the e-mail address to be used as the sender (appearing in the 'From' field of sent e-mails)."},{"key":"host","label":"SMTP server","placeholder":"smtp.example.com","help_text":"Enter the SMTP hostname. If you do not have this information available, contact your email service provider.","type":"SingleLineText","required":true},{"key":"name","label":"From domain","placeholder":"your-domain.com","type":"SingleLineText","required":true,"help_text":"Specify the domain name that will be used in the 'From' address (e.g., yourdomain.com). This should match the domain of the 'From' address."},{"key":"port","label":"SMTP port","placeholder":"Port","type":"SingleLineText","required":true,"help_text":"Enter the port number used by the SMTP server (e.g., 587 for TLS, 465 for SSL, or 25 for insecure connections)."},{"key":"username","label":"Username","placeholder":"Username","type":"SingleLineText","required":false,"help_text":"Enter the username to authenticate with the SMTP server. This is usually your email address."},{"key":"password","label":"Password","placeholder":"Password","type":"Password","required":false,"help_text":"Enter the password associated with the SMTP server username. Click the eye icon to view the password as you type"},{"key":"secure","label":"Use secure connection","placeholder":"Secure","type":"Checkbox","required":false,"help_text":"Enable this if your SMTP server requires a secure connection (SSL/TLS)."},{"key":"ignoreTLS","label":"Ignore TLS errors","placeholder":"Ignore TLS","type":"Checkbox","required":false,"help_text":"Enable this if you want to ignore any TLS errors that may occur during the connection. Enabling this disables STARTTLS even if SMTP servers support it, hence may compromise security."},{"key":"rejectUnauthorized","label":"Reject unauthorized","placeholder":"Reject unauthorized","type":"Checkbox","required":false,"help_text":"Disable this to allow connecting to an SMTP server that uses a self‑signed or otherwise invalid TLS certificate."}],"actions":[{"label":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully installed and email notification will use SMTP configuration","msgOnUninstall":"","docs":[]}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
mailersend	MailerSend	MailerSend email client	f	\N	0.0.2	\N	install	\N	plugins/mailersend.svg	\N	Email	Email	{"title":"Configure MailerSend","items":[{"key":"api_key","label":"API key","placeholder":"eg: ***************","type":"Password","required":true},{"key":"from","label":"From","placeholder":"eg: admin@run.com","type":"SingleLineText","required":true},{"key":"from_name","label":"From name","placeholder":"eg: Adam","type":"SingleLineText","required":true}],"actions":[{"label":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully configured! Email notifications are now set up using MailerSend.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
scaleway	Scaleway	Scaleway Object Storage is an S3-compatible object store from Scaleway Cloud Platform.	f	\N	0.0.4	\N	install	\N	plugins/scaleway.png	\N	Storage	Storage	{"title":"Setup Scaleway","items":[{"key":"bucket","label":"Bucket name","placeholder":"Bucket name","type":"SingleLineText","required":true},{"key":"region","label":"Region of bucket","placeholder":"Region of bucket","type":"SingleLineText","required":true},{"key":"access_key","label":"Access Key","placeholder":"Access Key","type":"SingleLineText","required":true},{"key":"access_secret","label":"Access Secret","placeholder":"Access Secret","type":"Password","required":true},{"key":"acl","label":"Access Control Lists (ACL)","placeholder":"Default set to public-read","type":"SingleLineText","required":false}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully configured! Attachments will now be stored in Scaleway Object Storage.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
ses	SES	Amazon Simple Email Service (SES) is a cost-effective, flexible, and scalable email service that enables developers to send mail from within any application.	f	\N	0.0.2	\N	install	\N	plugins/aws.png	\N	Email	Email	{"title":"Configure Amazon Simple Email Service (SES)","items":[{"key":"from","label":"From","placeholder":"From","type":"SingleLineText","required":true},{"key":"region","label":"Region","placeholder":"Region","type":"SingleLineText","required":true},{"key":"access_key","label":"Access Key","placeholder":"Access Key","type":"SingleLineText","required":true},{"key":"access_secret","label":"Access Secret","placeholder":"Access Secret","type":"Password","required":true}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully configured! Email notifications are now set up using Amazon SES.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
cloudflare-r2	Cloudflare R2	Cloudflare R2 is an S3-compatible, zero egress-fee, globally distributed object storage.	f	\N	0.0.3	\N	install	\N	plugins/r2.png	\N	Storage	Storage	{"title":"Configure Cloudflare R2 Storage","items":[{"key":"bucket","label":"Bucket Name","placeholder":"Bucket Name","type":"SingleLineText","required":true},{"key":"hostname","label":"Host Name","placeholder":"e.g.: *****.r2.cloudflarestorage.com","type":"SingleLineText","required":true},{"key":"access_key","label":"Access Key","placeholder":"Access Key","type":"SingleLineText","required":true},{"key":"access_secret","label":"Access Secret","placeholder":"Access Secret","type":"Password","required":true}],"actions":[{"label":"Test","placeholder":"Test","key":"test","actionType":"TEST","type":"Button"},{"label":"Save","placeholder":"Save","key":"save","actionType":"SUBMIT","type":"Button"}],"msgOnInstall":"Successfully configured! Attachments will now be stored in Cloudflare R2 Storage.","msgOnUninstall":""}	\N	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
\.


--
-- Data for Name: nc_row_color_conditions; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_row_color_conditions (id, fk_view_id, fk_workspace_id, base_id, color, nc_order, is_set_as_background, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_shared_bases; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_shared_bases (id, project_id, db_alias, roles, shared_base_id, enabled, password, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_shared_views_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_shared_views_v2 (id, fk_view_id, meta, query_params, view_id, show_all_fields, allow_copy, password, deleted, "order", created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_sort_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_sort_v2 (id, source_id, base_id, fk_view_id, fk_column_id, direction, "order", created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_sources_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_sources_v2 (id, base_id, alias, config, meta, is_meta, type, inflection_column, inflection_table, created_at, updated_at, enabled, "order", description, erd_uuid, deleted, is_schema_readonly, is_data_readonly, fk_integration_id, is_local, is_encrypted) FROM stdin;
brs1tao0osug2is	pfc8llztqct90f1	\N	{"schema":"pfc8llztqct90f1"}	\N	f	pg	camelize	camelize	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	t	1	\N	\N	f	f	f	\N	t	f
\.


--
-- Data for Name: nc_store; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_store (id, base_id, db_alias, key, value, type, env, tag, created_at, updated_at) FROM stdin;
1	\N		NC_DEBUG	{"nc:app":false,"nc:api:rest":false,"nc:api:source":false,"nc:api:gql":false,"nc:api:grpc":false,"nc:migrator":false,"nc:datamapper":false}	\N	\N	\N	\N	\N
2	\N		NC_PROJECT_COUNT	0	\N	\N	\N	\N	\N
3	\N	db	NC_MIGRATION_JOBS	{"version":"9","stall_check":1759286463628,"locked":false}	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
4	\N	db	nc_server_id	49bba3fd860bc67a326e965b2c752d7239dc093eae60420d14fbe1f1048ccf07	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
5	\N	db	NC_CONFIG_MAIN	{"version":"0258003"}	\N	\N	\N	2025-10-01 02:41:07+00	2025-10-01 02:41:07+00
\.


--
-- Data for Name: nc_sync_configs; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_sync_configs (id, fk_workspace_id, base_id, fk_integration_id, fk_model_id, sync_type, sync_trigger, sync_trigger_cron, sync_trigger_secret, sync_job_id, last_sync_at, next_sync_at, created_at, updated_at, title, sync_category, fk_parent_sync_config_id, on_delete_action) FROM stdin;
\.


--
-- Data for Name: nc_sync_logs_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_sync_logs_v2 (id, base_id, fk_sync_source_id, time_taken, status, status_details, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_sync_mappings; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_sync_mappings (id, fk_workspace_id, base_id, fk_sync_config_id, target_table, fk_model_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_sync_source_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_sync_source_v2 (id, title, type, details, deleted, enabled, "order", base_id, fk_user_id, created_at, updated_at, source_id) FROM stdin;
\.


--
-- Data for Name: nc_team_users_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_team_users_v2 (org_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_teams_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_teams_v2 (id, title, org_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_user_comment_notifications_preference; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_user_comment_notifications_preference (id, row_id, user_id, fk_model_id, source_id, base_id, preferences, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nc_user_refresh_tokens; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_user_refresh_tokens (fk_user_id, token, meta, expires_at, created_at, updated_at) FROM stdin;
us960mxogxe71ra8	a6e739809883ce271d5dc485aa71cabb7bf904dd8a094ad70f111277a05a78e677e854350f142483	\N	2025-10-31 04:23:28.604+00	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00
us960mxogxe71ra8	68ce0f38d143ee1beb98bab653d8b64ff977e8814d8fa32f293a0d5ac172eb0a994ba130d87e9657	\N	2025-10-31 04:27:01.721+00	2025-10-01 04:27:01+00	2025-10-01 04:27:01+00
\.


--
-- Data for Name: nc_users_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_users_v2 (id, email, password, salt, invite_token, invite_token_expires, reset_password_expires, reset_password_token, email_verification_token, email_verified, roles, created_at, updated_at, token_version, display_name, user_name, blocked, blocked_reason, deleted_at, is_deleted, meta, is_new_user) FROM stdin;
us960mxogxe71ra8	christopher.tastad@mssm.edu	$2a$10$VLY.UzIOZ4ymOGUEaRuB7.uxhSBYwAMNytahm3kYNi935Ut5zV3A.	$2a$10$VLY.UzIOZ4ymOGUEaRuB7.	\N	\N	\N	\N	40a167ff-22f0-45bf-98b0-cbe829cb6573	\N	org-level-creator,super	2025-10-01 04:23:28+00	2025-10-01 04:24:09+00	2253f4b7e4fa91c611d590fd63b025305f82e447d1c65c3be567bd7d80bed9162b8cc81689bb7fda	\N	\N	f	\N	\N	f	\N	f
\.


--
-- Data for Name: nc_views_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_views_v2 (id, source_id, base_id, fk_model_id, title, type, is_default, show_system_fields, lock_type, uuid, password, show, "order", created_at, updated_at, meta, description, created_by, owned_by, row_coloring_mode) FROM stdin;
vwvc9j4w93gk01yp	brs1tao0osug2is	pfc8llztqct90f1	mjrhqhpwjb0teal	Features	3	t	\N	collaborative	\N	\N	t	1	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00	{}	\N	\N	\N	\N
\.


--
-- Data for Name: nc_widgets_v2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.nc_widgets_v2 (id, fk_workspace_id, base_id, fk_dashboard_id, fk_model_id, fk_view_id, title, description, type, config, meta, "order", "position", created_at, updated_at, error) FROM stdin;
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.notification (id, type, body, is_read, is_deleted, fk_user_id, created_at, updated_at) FROM stdin;
ncaokqylg3wjbwap	app.welcome	{}	f	f	us960mxogxe71ra8	2025-10-01 04:23:28+00	2025-10-01 04:23:28+00
\.


--
-- Data for Name: xc_knex_migrations; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.xc_knex_migrations (id, name, batch, migration_time) FROM stdin;
1	project	1	2025-10-01 02:41:05.247+00
2	m2m	1	2025-10-01 02:41:05.249+00
3	fkn	1	2025-10-01 02:41:05.25+00
4	viewType	1	2025-10-01 02:41:05.252+00
5	viewName	1	2025-10-01 02:41:05.253+00
6	nc_006_alter_nc_shared_views	1	2025-10-01 02:41:05.258+00
7	nc_007_alter_nc_shared_views_1	1	2025-10-01 02:41:05.26+00
8	nc_008_add_nc_shared_bases	1	2025-10-01 02:41:05.27+00
9	nc_009_add_model_order	1	2025-10-01 02:41:05.279+00
10	nc_010_add_parent_title_column	1	2025-10-01 02:41:05.281+00
11	nc_011_remove_old_ses_plugin	1	2025-10-01 02:41:05.282+00
12	nc_012_cloud_cleanup	1	2025-10-01 02:41:05.363+00
\.


--
-- Data for Name: xc_knex_migrations_lock; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.xc_knex_migrations_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- Data for Name: xc_knex_migrationsv2; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.xc_knex_migrationsv2 (id, name, batch, migration_time) FROM stdin;
1	nc_011	1	2025-10-01 02:41:05.739+00
2	nc_012_alter_column_data_types	1	2025-10-01 02:41:05.747+00
3	nc_013_sync_source	1	2025-10-01 02:41:05.767+00
4	nc_014_alter_column_data_types	1	2025-10-01 02:41:05.773+00
5	nc_015_add_meta_col_in_column_table	1	2025-10-01 02:41:05.775+00
6	nc_016_alter_hooklog_payload_types	1	2025-10-01 02:41:05.788+00
7	nc_017_add_user_token_version_column	1	2025-10-01 02:41:05.789+00
8	nc_018_add_meta_in_view	1	2025-10-01 02:41:05.79+00
9	nc_019_add_meta_in_meta_tables	1	2025-10-01 02:41:05.797+00
10	nc_020_kanban_view	1	2025-10-01 02:41:05.802+00
11	nc_021_add_fields_in_token	1	2025-10-01 02:41:05.807+00
12	nc_022_qr_code_column_type	1	2025-10-01 02:41:05.816+00
13	nc_023_multiple_source	1	2025-10-01 02:41:05.821+00
14	nc_024_barcode_column_type	1	2025-10-01 02:41:05.831+00
15	nc_025_add_row_height	1	2025-10-01 02:41:05.833+00
16	nc_026_map_view	1	2025-10-01 02:41:05.86+00
17	nc_027_add_comparison_sub_op	1	2025-10-01 02:41:05.861+00
18	nc_028_add_enable_scanner_in_form_columns_meta_table	1	2025-10-01 02:41:05.863+00
19	nc_029_webhook	1	2025-10-01 02:41:05.865+00
20	nc_030_add_description_field	1	2025-10-01 02:41:05.868+00
21	nc_031_remove_fk_and_add_idx	1	2025-10-01 02:41:06.168+00
22	nc_033_add_group_by	1	2025-10-01 02:41:06.17+00
23	nc_034_erd_filter_and_notification	1	2025-10-01 02:41:06.222+00
24	nc_035_add_username_to_users	1	2025-10-01 02:41:06.226+00
25	nc_036_base_deleted	1	2025-10-01 02:41:06.227+00
26	nc_037_rename_project_and_base	1	2025-10-01 02:41:06.556+00
27	nc_038_formula_parsed_tree_column	1	2025-10-01 02:41:06.557+00
28	nc_039_sqlite_alter_column_types	1	2025-10-01 02:41:06.558+00
29	nc_040_form_view_alter_column_types	1	2025-10-01 02:41:06.562+00
30	nc_041_calendar_view	1	2025-10-01 02:41:06.579+00
31	nc_042_user_block	1	2025-10-01 02:41:06.581+00
32	nc_043_user_refresh_token	1	2025-10-01 02:41:06.595+00
33	nc_044_view_column_index	1	2025-10-01 02:41:06.616+00
34	nc_045_extensions	1	2025-10-01 02:41:06.627+00
35	nc_046_comment_mentions	1	2025-10-01 02:41:06.664+00
36	nc_047_comment_migration	1	2025-10-01 02:41:06.671+00
37	nc_048_view_links	1	2025-10-01 02:41:06.682+00
38	nc_049_clear_notifications	1	2025-10-01 02:41:06.684+00
39	nc_050_tenant_isolation	1	2025-10-01 02:41:06.902+00
40	nc_051_source_readonly_columns	1	2025-10-01 02:41:06.905+00
41	nc_052_field_aggregation	1	2025-10-01 02:41:06.906+00
42	nc_053_jobs	1	2025-10-01 02:41:06.914+00
43	nc_054_id_length	1	2025-10-01 02:41:07.378+00
44	nc_055_junction_pk	1	2025-10-01 02:41:07.382+00
45	nc_056_integration	1	2025-10-01 02:41:07.413+00
46	nc_057_file_references	1	2025-10-01 02:41:07.425+00
47	nc_058_button_colum	1	2025-10-01 02:41:07.43+00
48	nc_059_invited_by	1	2025-10-01 02:41:07.435+00
49	nc_060_descriptions	1	2025-10-01 02:41:07.439+00
50	nc_061_integration_is_default	1	2025-10-01 02:41:07.441+00
51	nc_062_integration_store	1	2025-10-01 02:41:07.454+00
52	nc_063_form_field_filter	1	2025-10-01 02:41:07.458+00
53	nc_064_pg_minimal_dbs	1	2025-10-01 02:41:07.46+00
54	nc_065_encrypt_flag	1	2025-10-01 02:41:07.463+00
55	nc_066_ai_button	1	2025-10-01 02:41:07.464+00
56	nc_067_personal_view	1	2025-10-01 02:41:07.473+00
57	nc_068_user_delete	1	2025-10-01 02:41:07.475+00
58	nc_069_ai_prompt	1	2025-10-01 02:41:07.486+00
59	nc_070_data_reflection	1	2025-10-01 02:41:07.494+00
60	nc_071_add_meta_in_users	1	2025-10-01 02:41:07.496+00
61	nc_072_col_button_pk	1	2025-10-01 02:41:07.5+00
62	nc_073_file_reference_indexes	1	2025-10-01 02:41:07.504+00
63	nc_074_missing_context_indexes	1	2025-10-01 02:41:07.525+00
64	nc_075_audit_refactor	1	2025-10-01 02:41:07.528+00
65	nc_076_sync_configs	1	2025-10-01 02:41:07.545+00
66	nc_077_column_index_name	1	2025-10-01 02:41:07.547+00
67	nc_078_mcp_tokens	1	2025-10-01 02:41:07.558+00
68	nc_079_cross_base_link	1	2025-10-01 02:41:07.56+00
69	nc_080_sync_mappings	1	2025-10-01 02:41:07.576+00
70	nc_081_audit	1	2025-10-01 02:41:07.603+00
71	nc_082_row_color_conditions	1	2025-10-01 02:41:07.616+00
72	nc_083_permissions	1	2025-10-01 02:41:07.642+00
73	nc_084_hook_trigger_fields	1	2025-10-01 02:41:07.649+00
74	nc_085_base_default_role	1	2025-10-01 02:41:07.651+00
75	nc_086_dashboards_widgets	1	2025-10-01 02:41:07.689+00
76	nc_087_widget_error	1	2025-10-01 02:41:07.691+00
77	nc_088_add_sso_client_to_api_tokens	1	2025-10-01 02:41:07.697+00
78	nc_089_dashboard_sharing	1	2025-10-01 02:41:07.702+00
79	nc_090_add_is_new_user_to_users	1	2025-10-01 02:41:07.704+00
80	nc_091_unify_model	1	2025-10-01 02:41:07.713+00
\.


--
-- Data for Name: xc_knex_migrationsv2_lock; Type: TABLE DATA; Schema: public; Owner: nocodb
--

COPY public.xc_knex_migrationsv2_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- Name: Features_id_seq; Type: SEQUENCE SET; Schema: pfc8llztqct90f1; Owner: nocodb
--

SELECT pg_catalog.setval('pfc8llztqct90f1."Features_id_seq"', 1, false);


--
-- Name: nc_api_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocodb
--

SELECT pg_catalog.setval('public.nc_api_tokens_id_seq', 1, false);


--
-- Name: nc_shared_bases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocodb
--

SELECT pg_catalog.setval('public.nc_shared_bases_id_seq', 1, false);


--
-- Name: nc_store_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocodb
--

SELECT pg_catalog.setval('public.nc_store_id_seq', 5, true);


--
-- Name: xc_knex_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocodb
--

SELECT pg_catalog.setval('public.xc_knex_migrations_id_seq', 12, true);


--
-- Name: xc_knex_migrations_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: nocodb
--

SELECT pg_catalog.setval('public.xc_knex_migrations_lock_index_seq', 1, true);


--
-- Name: xc_knex_migrationsv2_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocodb
--

SELECT pg_catalog.setval('public.xc_knex_migrationsv2_id_seq', 80, true);


--
-- Name: xc_knex_migrationsv2_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: nocodb
--

SELECT pg_catalog.setval('public.xc_knex_migrationsv2_lock_index_seq', 1, true);


--
-- Name: Features Features_pkey; Type: CONSTRAINT; Schema: pfc8llztqct90f1; Owner: nocodb
--

ALTER TABLE ONLY pfc8llztqct90f1."Features"
    ADD CONSTRAINT "Features_pkey" PRIMARY KEY (id);


--
-- Name: nc_api_tokens nc_api_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_api_tokens
    ADD CONSTRAINT nc_api_tokens_pkey PRIMARY KEY (id);


--
-- Name: nc_audit_v2_old nc_audit_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_audit_v2_old
    ADD CONSTRAINT nc_audit_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_audit_v2 nc_audit_v2_pkx; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_audit_v2
    ADD CONSTRAINT nc_audit_v2_pkx PRIMARY KEY (id);


--
-- Name: nc_base_users_v2 nc_base_users_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_base_users_v2
    ADD CONSTRAINT nc_base_users_v2_pkey PRIMARY KEY (base_id, fk_user_id);


--
-- Name: nc_sources_v2 nc_bases_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_sources_v2
    ADD CONSTRAINT nc_bases_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_calendar_view_columns_v2 nc_calendar_view_columns_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_calendar_view_columns_v2
    ADD CONSTRAINT nc_calendar_view_columns_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_calendar_view_range_v2 nc_calendar_view_range_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_calendar_view_range_v2
    ADD CONSTRAINT nc_calendar_view_range_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_calendar_view_v2 nc_calendar_view_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_calendar_view_v2
    ADD CONSTRAINT nc_calendar_view_v2_pkey PRIMARY KEY (fk_view_id);


--
-- Name: nc_col_barcode_v2 nc_col_barcode_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_col_barcode_v2
    ADD CONSTRAINT nc_col_barcode_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_col_button_v2 nc_col_button_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_col_button_v2
    ADD CONSTRAINT nc_col_button_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_col_formula_v2 nc_col_formula_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_col_formula_v2
    ADD CONSTRAINT nc_col_formula_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_col_long_text_v2 nc_col_long_text_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_col_long_text_v2
    ADD CONSTRAINT nc_col_long_text_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_col_lookup_v2 nc_col_lookup_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_col_lookup_v2
    ADD CONSTRAINT nc_col_lookup_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_col_qrcode_v2 nc_col_qrcode_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_col_qrcode_v2
    ADD CONSTRAINT nc_col_qrcode_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_col_relations_v2 nc_col_relations_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_col_relations_v2
    ADD CONSTRAINT nc_col_relations_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_col_rollup_v2 nc_col_rollup_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_col_rollup_v2
    ADD CONSTRAINT nc_col_rollup_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_col_select_options_v2 nc_col_select_options_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_col_select_options_v2
    ADD CONSTRAINT nc_col_select_options_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_columns_v2 nc_columns_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_columns_v2
    ADD CONSTRAINT nc_columns_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_comment_reactions nc_comment_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_comment_reactions
    ADD CONSTRAINT nc_comment_reactions_pkey PRIMARY KEY (id);


--
-- Name: nc_comments nc_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_comments
    ADD CONSTRAINT nc_comments_pkey PRIMARY KEY (id);


--
-- Name: nc_dashboards_v2 nc_dashboards_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_dashboards_v2
    ADD CONSTRAINT nc_dashboards_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_data_reflection nc_data_reflection_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_data_reflection
    ADD CONSTRAINT nc_data_reflection_pkey PRIMARY KEY (id);


--
-- Name: nc_disabled_models_for_role_v2 nc_disabled_models_for_role_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_disabled_models_for_role_v2
    ADD CONSTRAINT nc_disabled_models_for_role_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_extensions nc_extensions_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_extensions
    ADD CONSTRAINT nc_extensions_pkey PRIMARY KEY (id);


--
-- Name: nc_file_references nc_file_references_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_file_references
    ADD CONSTRAINT nc_file_references_pkey PRIMARY KEY (id);


--
-- Name: nc_filter_exp_v2 nc_filter_exp_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_filter_exp_v2
    ADD CONSTRAINT nc_filter_exp_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_form_view_columns_v2 nc_form_view_columns_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_form_view_columns_v2
    ADD CONSTRAINT nc_form_view_columns_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_form_view_v2 nc_form_view_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_form_view_v2
    ADD CONSTRAINT nc_form_view_v2_pkey PRIMARY KEY (fk_view_id);


--
-- Name: nc_gallery_view_columns_v2 nc_gallery_view_columns_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_gallery_view_columns_v2
    ADD CONSTRAINT nc_gallery_view_columns_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_gallery_view_v2 nc_gallery_view_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_gallery_view_v2
    ADD CONSTRAINT nc_gallery_view_v2_pkey PRIMARY KEY (fk_view_id);


--
-- Name: nc_grid_view_columns_v2 nc_grid_view_columns_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_grid_view_columns_v2
    ADD CONSTRAINT nc_grid_view_columns_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_grid_view_v2 nc_grid_view_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_grid_view_v2
    ADD CONSTRAINT nc_grid_view_v2_pkey PRIMARY KEY (fk_view_id);


--
-- Name: nc_hook_logs_v2 nc_hook_logs_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_hook_logs_v2
    ADD CONSTRAINT nc_hook_logs_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_hook_trigger_fields nc_hook_trigger_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_hook_trigger_fields
    ADD CONSTRAINT nc_hook_trigger_fields_pkey PRIMARY KEY (fk_workspace_id, base_id, fk_hook_id, fk_column_id);


--
-- Name: nc_hooks_v2 nc_hooks_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_hooks_v2
    ADD CONSTRAINT nc_hooks_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_integrations_store_v2 nc_integrations_store_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_integrations_store_v2
    ADD CONSTRAINT nc_integrations_store_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_integrations_v2 nc_integrations_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_integrations_v2
    ADD CONSTRAINT nc_integrations_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_jobs nc_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_jobs
    ADD CONSTRAINT nc_jobs_pkey PRIMARY KEY (id);


--
-- Name: nc_kanban_view_columns_v2 nc_kanban_view_columns_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_kanban_view_columns_v2
    ADD CONSTRAINT nc_kanban_view_columns_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_kanban_view_v2 nc_kanban_view_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_kanban_view_v2
    ADD CONSTRAINT nc_kanban_view_v2_pkey PRIMARY KEY (fk_view_id);


--
-- Name: nc_map_view_columns_v2 nc_map_view_columns_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_map_view_columns_v2
    ADD CONSTRAINT nc_map_view_columns_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_map_view_v2 nc_map_view_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_map_view_v2
    ADD CONSTRAINT nc_map_view_v2_pkey PRIMARY KEY (fk_view_id);


--
-- Name: nc_mcp_tokens nc_mcp_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_mcp_tokens
    ADD CONSTRAINT nc_mcp_tokens_pkey PRIMARY KEY (id);


--
-- Name: nc_models_v2 nc_models_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_models_v2
    ADD CONSTRAINT nc_models_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_orgs_v2 nc_orgs_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_orgs_v2
    ADD CONSTRAINT nc_orgs_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_permission_subjects nc_permission_subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_permission_subjects
    ADD CONSTRAINT nc_permission_subjects_pkey PRIMARY KEY (fk_permission_id, subject_type, subject_id);


--
-- Name: nc_permissions nc_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_permissions
    ADD CONSTRAINT nc_permissions_pkey PRIMARY KEY (id);


--
-- Name: nc_plugins_v2 nc_plugins_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_plugins_v2
    ADD CONSTRAINT nc_plugins_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_bases_v2 nc_projects_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_bases_v2
    ADD CONSTRAINT nc_projects_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_row_color_conditions nc_row_color_conditions_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_row_color_conditions
    ADD CONSTRAINT nc_row_color_conditions_pkey PRIMARY KEY (id);


--
-- Name: nc_shared_bases nc_shared_bases_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_shared_bases
    ADD CONSTRAINT nc_shared_bases_pkey PRIMARY KEY (id);


--
-- Name: nc_shared_views_v2 nc_shared_views_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_shared_views_v2
    ADD CONSTRAINT nc_shared_views_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_sort_v2 nc_sort_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_sort_v2
    ADD CONSTRAINT nc_sort_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_store nc_store_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_store
    ADD CONSTRAINT nc_store_pkey PRIMARY KEY (id);


--
-- Name: nc_sync_configs nc_sync_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_sync_configs
    ADD CONSTRAINT nc_sync_configs_pkey PRIMARY KEY (id);


--
-- Name: nc_sync_logs_v2 nc_sync_logs_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_sync_logs_v2
    ADD CONSTRAINT nc_sync_logs_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_sync_mappings nc_sync_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_sync_mappings
    ADD CONSTRAINT nc_sync_mappings_pkey PRIMARY KEY (id);


--
-- Name: nc_sync_source_v2 nc_sync_source_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_sync_source_v2
    ADD CONSTRAINT nc_sync_source_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_teams_v2 nc_teams_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_teams_v2
    ADD CONSTRAINT nc_teams_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_user_comment_notifications_preference nc_user_comment_notifications_preference_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_user_comment_notifications_preference
    ADD CONSTRAINT nc_user_comment_notifications_preference_pkey PRIMARY KEY (id);


--
-- Name: nc_users_v2 nc_users_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_users_v2
    ADD CONSTRAINT nc_users_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_views_v2 nc_views_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_views_v2
    ADD CONSTRAINT nc_views_v2_pkey PRIMARY KEY (id);


--
-- Name: nc_widgets_v2 nc_widgets_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_widgets_v2
    ADD CONSTRAINT nc_widgets_v2_pkey PRIMARY KEY (id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: xc_knex_migrations_lock xc_knex_migrations_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.xc_knex_migrations_lock
    ADD CONSTRAINT xc_knex_migrations_lock_pkey PRIMARY KEY (index);


--
-- Name: xc_knex_migrations xc_knex_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.xc_knex_migrations
    ADD CONSTRAINT xc_knex_migrations_pkey PRIMARY KEY (id);


--
-- Name: xc_knex_migrationsv2_lock xc_knex_migrationsv2_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.xc_knex_migrationsv2_lock
    ADD CONSTRAINT xc_knex_migrationsv2_lock_pkey PRIMARY KEY (index);


--
-- Name: xc_knex_migrationsv2 xc_knex_migrationsv2_pkey; Type: CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.xc_knex_migrationsv2
    ADD CONSTRAINT xc_knex_migrationsv2_pkey PRIMARY KEY (id);


--
-- Name: Features_order_idx; Type: INDEX; Schema: pfc8llztqct90f1; Owner: nocodb
--

CREATE INDEX "Features_order_idx" ON pfc8llztqct90f1."Features" USING btree (nc_order);


--
-- Name: nc_api_tokens_fk_sso_client_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_api_tokens_fk_sso_client_id_index ON public.nc_api_tokens USING btree (fk_sso_client_id);


--
-- Name: nc_api_tokens_fk_user_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_api_tokens_fk_user_id_index ON public.nc_api_tokens USING btree (fk_user_id);


--
-- Name: nc_audit_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_audit_v2_base_id_index ON public.nc_audit_v2_old USING btree (base_id);


--
-- Name: nc_audit_v2_fk_model_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_audit_v2_fk_model_id_index ON public.nc_audit_v2_old USING btree (fk_model_id);


--
-- Name: nc_audit_v2_fk_workspace_idx; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_audit_v2_fk_workspace_idx ON public.nc_audit_v2 USING btree (fk_workspace_id);


--
-- Name: nc_audit_v2_old_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_audit_v2_old_id_index ON public.nc_audit_v2 USING btree (old_id);


--
-- Name: nc_audit_v2_row_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_audit_v2_row_id_index ON public.nc_audit_v2_old USING btree (row_id);


--
-- Name: nc_audit_v2_tenant_idx; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_audit_v2_tenant_idx ON public.nc_audit_v2 USING btree (base_id, fk_workspace_id);


--
-- Name: nc_base_users_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_base_users_v2_base_id_index ON public.nc_base_users_v2 USING btree (base_id);


--
-- Name: nc_base_users_v2_invited_by_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_base_users_v2_invited_by_index ON public.nc_base_users_v2 USING btree (invited_by);


--
-- Name: nc_calendar_view_columns_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_calendar_view_columns_v2_base_id_index ON public.nc_calendar_view_columns_v2 USING btree (base_id);


--
-- Name: nc_calendar_view_columns_v2_fk_view_id_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_calendar_view_columns_v2_fk_view_id_fk_column_id_index ON public.nc_calendar_view_columns_v2 USING btree (fk_view_id, fk_column_id);


--
-- Name: nc_calendar_view_range_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_calendar_view_range_v2_base_id_index ON public.nc_calendar_view_range_v2 USING btree (base_id);


--
-- Name: nc_calendar_view_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_calendar_view_v2_base_id_index ON public.nc_calendar_view_v2 USING btree (base_id);


--
-- Name: nc_col_barcode_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_barcode_v2_base_id_index ON public.nc_col_barcode_v2 USING btree (base_id);


--
-- Name: nc_col_barcode_v2_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_barcode_v2_fk_column_id_index ON public.nc_col_barcode_v2 USING btree (fk_column_id);


--
-- Name: nc_col_button_context; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_button_context ON public.nc_col_button_v2 USING btree (base_id, fk_workspace_id);


--
-- Name: nc_col_button_v2_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_button_v2_fk_column_id_index ON public.nc_col_button_v2 USING btree (fk_column_id);


--
-- Name: nc_col_formula_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_formula_v2_base_id_index ON public.nc_col_formula_v2 USING btree (base_id);


--
-- Name: nc_col_formula_v2_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_formula_v2_fk_column_id_index ON public.nc_col_formula_v2 USING btree (fk_column_id);


--
-- Name: nc_col_long_text_context; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_long_text_context ON public.nc_col_long_text_v2 USING btree (base_id, fk_workspace_id);


--
-- Name: nc_col_long_text_v2_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_long_text_v2_fk_column_id_index ON public.nc_col_long_text_v2 USING btree (fk_column_id);


--
-- Name: nc_col_lookup_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_lookup_v2_base_id_index ON public.nc_col_lookup_v2 USING btree (base_id);


--
-- Name: nc_col_lookup_v2_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_lookup_v2_fk_column_id_index ON public.nc_col_lookup_v2 USING btree (fk_column_id);


--
-- Name: nc_col_lookup_v2_fk_lookup_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_lookup_v2_fk_lookup_column_id_index ON public.nc_col_lookup_v2 USING btree (fk_lookup_column_id);


--
-- Name: nc_col_lookup_v2_fk_relation_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_lookup_v2_fk_relation_column_id_index ON public.nc_col_lookup_v2 USING btree (fk_relation_column_id);


--
-- Name: nc_col_qrcode_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_qrcode_v2_base_id_index ON public.nc_col_qrcode_v2 USING btree (base_id);


--
-- Name: nc_col_qrcode_v2_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_qrcode_v2_fk_column_id_index ON public.nc_col_qrcode_v2 USING btree (fk_column_id);


--
-- Name: nc_col_relations_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_relations_v2_base_id_index ON public.nc_col_relations_v2 USING btree (base_id);


--
-- Name: nc_col_relations_v2_fk_child_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_relations_v2_fk_child_column_id_index ON public.nc_col_relations_v2 USING btree (fk_child_column_id);


--
-- Name: nc_col_relations_v2_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_relations_v2_fk_column_id_index ON public.nc_col_relations_v2 USING btree (fk_column_id);


--
-- Name: nc_col_relations_v2_fk_mm_child_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_relations_v2_fk_mm_child_column_id_index ON public.nc_col_relations_v2 USING btree (fk_mm_child_column_id);


--
-- Name: nc_col_relations_v2_fk_mm_model_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_relations_v2_fk_mm_model_id_index ON public.nc_col_relations_v2 USING btree (fk_mm_model_id);


--
-- Name: nc_col_relations_v2_fk_mm_parent_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_relations_v2_fk_mm_parent_column_id_index ON public.nc_col_relations_v2 USING btree (fk_mm_parent_column_id);


--
-- Name: nc_col_relations_v2_fk_parent_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_relations_v2_fk_parent_column_id_index ON public.nc_col_relations_v2 USING btree (fk_parent_column_id);


--
-- Name: nc_col_relations_v2_fk_related_model_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_relations_v2_fk_related_model_id_index ON public.nc_col_relations_v2 USING btree (fk_related_model_id);


--
-- Name: nc_col_relations_v2_fk_target_view_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_relations_v2_fk_target_view_id_index ON public.nc_col_relations_v2 USING btree (fk_target_view_id);


--
-- Name: nc_col_rollup_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_rollup_v2_base_id_index ON public.nc_col_rollup_v2 USING btree (base_id);


--
-- Name: nc_col_rollup_v2_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_rollup_v2_fk_column_id_index ON public.nc_col_rollup_v2 USING btree (fk_column_id);


--
-- Name: nc_col_rollup_v2_fk_relation_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_rollup_v2_fk_relation_column_id_index ON public.nc_col_rollup_v2 USING btree (fk_relation_column_id);


--
-- Name: nc_col_rollup_v2_fk_rollup_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_rollup_v2_fk_rollup_column_id_index ON public.nc_col_rollup_v2 USING btree (fk_rollup_column_id);


--
-- Name: nc_col_select_options_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_select_options_v2_base_id_index ON public.nc_col_select_options_v2 USING btree (base_id);


--
-- Name: nc_col_select_options_v2_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_col_select_options_v2_fk_column_id_index ON public.nc_col_select_options_v2 USING btree (fk_column_id);


--
-- Name: nc_columns_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_columns_v2_base_id_index ON public.nc_columns_v2 USING btree (base_id);


--
-- Name: nc_columns_v2_fk_model_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_columns_v2_fk_model_id_index ON public.nc_columns_v2 USING btree (fk_model_id);


--
-- Name: nc_comment_reactions_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_comment_reactions_base_id_index ON public.nc_comment_reactions USING btree (base_id);


--
-- Name: nc_comment_reactions_comment_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_comment_reactions_comment_id_index ON public.nc_comment_reactions USING btree (comment_id);


--
-- Name: nc_comment_reactions_row_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_comment_reactions_row_id_index ON public.nc_comment_reactions USING btree (row_id);


--
-- Name: nc_comments_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_comments_base_id_index ON public.nc_comments USING btree (base_id);


--
-- Name: nc_comments_row_id_fk_model_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_comments_row_id_fk_model_id_index ON public.nc_comments USING btree (row_id, fk_model_id);


--
-- Name: nc_dashboards_context; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_dashboards_context ON public.nc_dashboards_v2 USING btree (base_id, fk_workspace_id);


--
-- Name: nc_data_reflection_fk_workspace_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_data_reflection_fk_workspace_id_index ON public.nc_data_reflection USING btree (fk_workspace_id);


--
-- Name: nc_disabled_models_for_role_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_disabled_models_for_role_v2_base_id_index ON public.nc_disabled_models_for_role_v2 USING btree (base_id);


--
-- Name: nc_disabled_models_for_role_v2_fk_view_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_disabled_models_for_role_v2_fk_view_id_index ON public.nc_disabled_models_for_role_v2 USING btree (fk_view_id);


--
-- Name: nc_extensions_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_extensions_base_id_index ON public.nc_extensions USING btree (base_id);


--
-- Name: nc_filter_exp_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_filter_exp_v2_base_id_index ON public.nc_filter_exp_v2 USING btree (base_id);


--
-- Name: nc_filter_exp_v2_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_filter_exp_v2_fk_column_id_index ON public.nc_filter_exp_v2 USING btree (fk_column_id);


--
-- Name: nc_filter_exp_v2_fk_hook_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_filter_exp_v2_fk_hook_id_index ON public.nc_filter_exp_v2 USING btree (fk_hook_id);


--
-- Name: nc_filter_exp_v2_fk_link_col_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_filter_exp_v2_fk_link_col_id_index ON public.nc_filter_exp_v2 USING btree (fk_link_col_id);


--
-- Name: nc_filter_exp_v2_fk_parent_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_filter_exp_v2_fk_parent_column_id_index ON public.nc_filter_exp_v2 USING btree (fk_parent_column_id);


--
-- Name: nc_filter_exp_v2_fk_parent_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_filter_exp_v2_fk_parent_id_index ON public.nc_filter_exp_v2 USING btree (fk_parent_id);


--
-- Name: nc_filter_exp_v2_fk_value_col_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_filter_exp_v2_fk_value_col_id_index ON public.nc_filter_exp_v2 USING btree (fk_value_col_id);


--
-- Name: nc_filter_exp_v2_fk_view_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_filter_exp_v2_fk_view_id_index ON public.nc_filter_exp_v2 USING btree (fk_view_id);


--
-- Name: nc_filter_exp_v2_fk_widget_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_filter_exp_v2_fk_widget_id_index ON public.nc_filter_exp_v2 USING btree (fk_widget_id);


--
-- Name: nc_form_view_columns_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_form_view_columns_v2_base_id_index ON public.nc_form_view_columns_v2 USING btree (base_id);


--
-- Name: nc_form_view_columns_v2_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_form_view_columns_v2_fk_column_id_index ON public.nc_form_view_columns_v2 USING btree (fk_column_id);


--
-- Name: nc_form_view_columns_v2_fk_view_id_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_form_view_columns_v2_fk_view_id_fk_column_id_index ON public.nc_form_view_columns_v2 USING btree (fk_view_id, fk_column_id);


--
-- Name: nc_form_view_columns_v2_fk_view_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_form_view_columns_v2_fk_view_id_index ON public.nc_form_view_columns_v2 USING btree (fk_view_id);


--
-- Name: nc_form_view_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_form_view_v2_base_id_index ON public.nc_form_view_v2 USING btree (base_id);


--
-- Name: nc_form_view_v2_fk_view_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_form_view_v2_fk_view_id_index ON public.nc_form_view_v2 USING btree (fk_view_id);


--
-- Name: nc_fr_context; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_fr_context ON public.nc_file_references USING btree (base_id, fk_workspace_id);


--
-- Name: nc_gallery_view_columns_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_gallery_view_columns_v2_base_id_index ON public.nc_gallery_view_columns_v2 USING btree (base_id);


--
-- Name: nc_gallery_view_columns_v2_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_gallery_view_columns_v2_fk_column_id_index ON public.nc_gallery_view_columns_v2 USING btree (fk_column_id);


--
-- Name: nc_gallery_view_columns_v2_fk_view_id_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_gallery_view_columns_v2_fk_view_id_fk_column_id_index ON public.nc_gallery_view_columns_v2 USING btree (fk_view_id, fk_column_id);


--
-- Name: nc_gallery_view_columns_v2_fk_view_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_gallery_view_columns_v2_fk_view_id_index ON public.nc_gallery_view_columns_v2 USING btree (fk_view_id);


--
-- Name: nc_gallery_view_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_gallery_view_v2_base_id_index ON public.nc_gallery_view_v2 USING btree (base_id);


--
-- Name: nc_gallery_view_v2_fk_view_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_gallery_view_v2_fk_view_id_index ON public.nc_gallery_view_v2 USING btree (fk_view_id);


--
-- Name: nc_grid_view_columns_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_grid_view_columns_v2_base_id_index ON public.nc_grid_view_columns_v2 USING btree (base_id);


--
-- Name: nc_grid_view_columns_v2_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_grid_view_columns_v2_fk_column_id_index ON public.nc_grid_view_columns_v2 USING btree (fk_column_id);


--
-- Name: nc_grid_view_columns_v2_fk_view_id_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_grid_view_columns_v2_fk_view_id_fk_column_id_index ON public.nc_grid_view_columns_v2 USING btree (fk_view_id, fk_column_id);


--
-- Name: nc_grid_view_columns_v2_fk_view_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_grid_view_columns_v2_fk_view_id_index ON public.nc_grid_view_columns_v2 USING btree (fk_view_id);


--
-- Name: nc_grid_view_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_grid_view_v2_base_id_index ON public.nc_grid_view_v2 USING btree (base_id);


--
-- Name: nc_grid_view_v2_fk_view_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_grid_view_v2_fk_view_id_index ON public.nc_grid_view_v2 USING btree (fk_view_id);


--
-- Name: nc_hook_logs_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_hook_logs_v2_base_id_index ON public.nc_hook_logs_v2 USING btree (base_id);


--
-- Name: nc_hooks_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_hooks_v2_base_id_index ON public.nc_hooks_v2 USING btree (base_id);


--
-- Name: nc_hooks_v2_fk_model_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_hooks_v2_fk_model_id_index ON public.nc_hooks_v2 USING btree (fk_model_id);


--
-- Name: nc_integrations_store_v2_fk_integration_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_integrations_store_v2_fk_integration_id_index ON public.nc_integrations_store_v2 USING btree (fk_integration_id);


--
-- Name: nc_integrations_v2_created_by_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_integrations_v2_created_by_index ON public.nc_integrations_v2 USING btree (created_by);


--
-- Name: nc_integrations_v2_type_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_integrations_v2_type_index ON public.nc_integrations_v2 USING btree (type);


--
-- Name: nc_jobs_context; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_jobs_context ON public.nc_jobs USING btree (base_id, fk_workspace_id);


--
-- Name: nc_kanban_view_columns_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_kanban_view_columns_v2_base_id_index ON public.nc_kanban_view_columns_v2 USING btree (base_id);


--
-- Name: nc_kanban_view_columns_v2_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_kanban_view_columns_v2_fk_column_id_index ON public.nc_kanban_view_columns_v2 USING btree (fk_column_id);


--
-- Name: nc_kanban_view_columns_v2_fk_view_id_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_kanban_view_columns_v2_fk_view_id_fk_column_id_index ON public.nc_kanban_view_columns_v2 USING btree (fk_view_id, fk_column_id);


--
-- Name: nc_kanban_view_columns_v2_fk_view_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_kanban_view_columns_v2_fk_view_id_index ON public.nc_kanban_view_columns_v2 USING btree (fk_view_id);


--
-- Name: nc_kanban_view_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_kanban_view_v2_base_id_index ON public.nc_kanban_view_v2 USING btree (base_id);


--
-- Name: nc_kanban_view_v2_fk_grp_col_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_kanban_view_v2_fk_grp_col_id_index ON public.nc_kanban_view_v2 USING btree (fk_grp_col_id);


--
-- Name: nc_kanban_view_v2_fk_view_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_kanban_view_v2_fk_view_id_index ON public.nc_kanban_view_v2 USING btree (fk_view_id);


--
-- Name: nc_map_view_columns_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_map_view_columns_v2_base_id_index ON public.nc_map_view_columns_v2 USING btree (base_id);


--
-- Name: nc_map_view_columns_v2_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_map_view_columns_v2_fk_column_id_index ON public.nc_map_view_columns_v2 USING btree (fk_column_id);


--
-- Name: nc_map_view_columns_v2_fk_view_id_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_map_view_columns_v2_fk_view_id_fk_column_id_index ON public.nc_map_view_columns_v2 USING btree (fk_view_id, fk_column_id);


--
-- Name: nc_map_view_columns_v2_fk_view_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_map_view_columns_v2_fk_view_id_index ON public.nc_map_view_columns_v2 USING btree (fk_view_id);


--
-- Name: nc_map_view_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_map_view_v2_base_id_index ON public.nc_map_view_v2 USING btree (base_id);


--
-- Name: nc_map_view_v2_fk_geo_data_col_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_map_view_v2_fk_geo_data_col_id_index ON public.nc_map_view_v2 USING btree (fk_geo_data_col_id);


--
-- Name: nc_map_view_v2_fk_view_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_map_view_v2_fk_view_id_index ON public.nc_map_view_v2 USING btree (fk_view_id);


--
-- Name: nc_mc_tokens_context; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_mc_tokens_context ON public.nc_mcp_tokens USING btree (base_id, fk_workspace_id);


--
-- Name: nc_models_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_models_v2_base_id_index ON public.nc_models_v2 USING btree (base_id);


--
-- Name: nc_models_v2_source_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_models_v2_source_id_index ON public.nc_models_v2 USING btree (source_id);


--
-- Name: nc_models_v2_type_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_models_v2_type_index ON public.nc_models_v2 USING btree (type);


--
-- Name: nc_models_v2_uuid_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_models_v2_uuid_index ON public.nc_models_v2 USING btree (uuid);


--
-- Name: nc_permission_subjects_context; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_permission_subjects_context ON public.nc_permission_subjects USING btree (fk_workspace_id, base_id);


--
-- Name: nc_permissions_context; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_permissions_context ON public.nc_permissions USING btree (base_id, fk_workspace_id);


--
-- Name: nc_permissions_entity; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_permissions_entity ON public.nc_permissions USING btree (entity, entity_id, permission);


--
-- Name: nc_project_users_v2_fk_user_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_project_users_v2_fk_user_id_index ON public.nc_base_users_v2 USING btree (fk_user_id);


--
-- Name: nc_record_audit_v2_tenant_idx; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_record_audit_v2_tenant_idx ON public.nc_audit_v2 USING btree (base_id, fk_model_id, row_id, fk_workspace_id);


--
-- Name: nc_row_color_conditions_fk_view_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_row_color_conditions_fk_view_id_index ON public.nc_row_color_conditions USING btree (fk_view_id);


--
-- Name: nc_row_color_conditions_fk_workspace_id_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_row_color_conditions_fk_workspace_id_base_id_index ON public.nc_row_color_conditions USING btree (fk_workspace_id, base_id);


--
-- Name: nc_shared_views_v2_fk_view_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_shared_views_v2_fk_view_id_index ON public.nc_shared_views_v2 USING btree (fk_view_id);


--
-- Name: nc_sort_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_sort_v2_base_id_index ON public.nc_sort_v2 USING btree (base_id);


--
-- Name: nc_sort_v2_fk_column_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_sort_v2_fk_column_id_index ON public.nc_sort_v2 USING btree (fk_column_id);


--
-- Name: nc_sort_v2_fk_view_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_sort_v2_fk_view_id_index ON public.nc_sort_v2 USING btree (fk_view_id);


--
-- Name: nc_sources_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_sources_v2_base_id_index ON public.nc_sources_v2 USING btree (base_id);


--
-- Name: nc_sources_v2_fk_integration_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_sources_v2_fk_integration_id_index ON public.nc_sources_v2 USING btree (fk_integration_id);


--
-- Name: nc_store_key_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_store_key_index ON public.nc_store USING btree (key);


--
-- Name: nc_sync_configs_context; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_sync_configs_context ON public.nc_sync_configs USING btree (base_id, fk_workspace_id);


--
-- Name: nc_sync_configs_parent_idx; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_sync_configs_parent_idx ON public.nc_sync_configs USING btree (fk_parent_sync_config_id);


--
-- Name: nc_sync_logs_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_sync_logs_v2_base_id_index ON public.nc_sync_logs_v2 USING btree (base_id);


--
-- Name: nc_sync_mappings_context; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_sync_mappings_context ON public.nc_sync_mappings USING btree (base_id, fk_workspace_id);


--
-- Name: nc_sync_mappings_sync_config_idx; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_sync_mappings_sync_config_idx ON public.nc_sync_mappings USING btree (fk_sync_config_id);


--
-- Name: nc_sync_source_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_sync_source_v2_base_id_index ON public.nc_sync_source_v2 USING btree (base_id);


--
-- Name: nc_sync_source_v2_source_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_sync_source_v2_source_id_index ON public.nc_sync_source_v2 USING btree (source_id);


--
-- Name: nc_user_comment_notifications_preference_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_user_comment_notifications_preference_base_id_index ON public.nc_user_comment_notifications_preference USING btree (base_id);


--
-- Name: nc_user_refresh_tokens_expires_at_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_user_refresh_tokens_expires_at_index ON public.nc_user_refresh_tokens USING btree (expires_at);


--
-- Name: nc_user_refresh_tokens_fk_user_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_user_refresh_tokens_fk_user_id_index ON public.nc_user_refresh_tokens USING btree (fk_user_id);


--
-- Name: nc_user_refresh_tokens_token_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_user_refresh_tokens_token_index ON public.nc_user_refresh_tokens USING btree (token);


--
-- Name: nc_users_v2_email_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_users_v2_email_index ON public.nc_users_v2 USING btree (email);


--
-- Name: nc_views_v2_base_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_views_v2_base_id_index ON public.nc_views_v2 USING btree (base_id);


--
-- Name: nc_views_v2_created_by_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_views_v2_created_by_index ON public.nc_views_v2 USING btree (created_by);


--
-- Name: nc_views_v2_fk_model_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_views_v2_fk_model_id_index ON public.nc_views_v2 USING btree (fk_model_id);


--
-- Name: nc_views_v2_owned_by_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_views_v2_owned_by_index ON public.nc_views_v2 USING btree (owned_by);


--
-- Name: nc_widgets_context; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_widgets_context ON public.nc_widgets_v2 USING btree (base_id, fk_workspace_id);


--
-- Name: nc_widgets_dashboard_idx; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX nc_widgets_dashboard_idx ON public.nc_widgets_v2 USING btree (fk_dashboard_id);


--
-- Name: notification_created_at_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX notification_created_at_index ON public.notification USING btree (created_at);


--
-- Name: notification_fk_user_id_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX notification_fk_user_id_index ON public.notification USING btree (fk_user_id);


--
-- Name: share_uuid_idx; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX share_uuid_idx ON public.nc_dashboards_v2 USING btree (uuid);


--
-- Name: sync_configs_integration_model; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX sync_configs_integration_model ON public.nc_sync_configs USING btree (fk_model_id, fk_integration_id);


--
-- Name: user_comments_preference_index; Type: INDEX; Schema: public; Owner: nocodb
--

CREATE INDEX user_comments_preference_index ON public.nc_user_comment_notifications_preference USING btree (user_id, row_id, fk_model_id);


--
-- Name: nc_team_users_v2 nc_team_users_v2_org_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_team_users_v2
    ADD CONSTRAINT nc_team_users_v2_org_id_foreign FOREIGN KEY (org_id) REFERENCES public.nc_orgs_v2(id);


--
-- Name: nc_team_users_v2 nc_team_users_v2_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_team_users_v2
    ADD CONSTRAINT nc_team_users_v2_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.nc_users_v2(id);


--
-- Name: nc_teams_v2 nc_teams_v2_org_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: nocodb
--

ALTER TABLE ONLY public.nc_teams_v2
    ADD CONSTRAINT nc_teams_v2_org_id_foreign FOREIGN KEY (org_id) REFERENCES public.nc_orgs_v2(id);


--
-- PostgreSQL database dump complete
--

\unrestrict yH8OQvbeEbM0HhpJYhb60y5TWEVFWOhvKvDckcR4NXNfZ7I1e6Rpn64pKIBHSfN

